# Implementation Plan: MediAI — Intelligent Health Assistant

Build a complete, modern, professional, and highly interactive healthcare web application titled **“AI-Powered Medical Chatbot for Symptom Analysis and Health Consultation”** (Brand: **MediAI — Intelligent Health Assistant**). Designed as a final-year engineering capstone project demonstration with enterprise-grade UI, machine learning backend, client-side offline fallback, and clinical triage safety guardrails.

---

## User Review Required

> [!IMPORTANT]
> - **Dual Runtime Mode**: We will build the application with a **Flask + Scikit-Learn Python backend** (`app.py`) for real ML model inference AND a **self-contained client-side AI engine** (`ai-engine.js`). This guarantees that the project can be demonstrated both with the live Python server (`http://localhost:5000`) and directly opened in any web browser without any setup.
> - **Medical Ethics & Safety**: The system explicitly enforces OTC (over-the-counter) educational suggestions only. Routine medicine recommendations are automatically blocked when red-flag emergency symptoms or contraindications (allergies, pregnancy, pediatric, severe illness) are detected.

---

## Architecture & Technical Stack

```mermaid
flowchart TD
    User([User / Patient]) --> UI[Modern Glassmorphic Web UI\nTailwind CSS + Custom Animations]
    
    subgraph Frontend [Client-Side Layer]
        Nav[Sticky Nav & Dark/Light Mode]
        SympForm[Intelligent Symptom Intake Form]
        ChatWidget[MediAI Conversational Assistant]
        HistDash[Health History & Chart.js Trends]
        DocBooking[Doctor Consultation & Triage]
        ClientAI[Client-Side AI Engine Fallback]
    end
    
    UI --> SympForm
    UI --> ChatWidget
    UI --> HistDash
    UI --> DocBooking
    
    subgraph Backend [Python 3.13 Flask & ML Service]
        API[Flask REST API Server]
        ML[Scikit-Learn Naive Bayes & Random Forest Classifier]
        RuleEngine[Safety & Contraindication Checker]
        RedFlag[Red Flag Emergency Detector]
    end
    
    SympForm -->|POST /api/analyze| API
    ChatWidget -->|POST /api/chat| API
    API --> ML
    API --> RuleEngine
    API --> RedFlag
    
    SympForm -.->|Fallback if offline| ClientAI
    ChatWidget -.->|Fallback if offline| ClientAI
```

---

## Proposed Changes

Project will be created in `C:\Users\User\.gemini\antigravity\scratch\mediai-health-assistant\`.

### Core Backend & Machine Learning

#### [NEW] [ml_engine.py](file:///C:/Users/User/.gemini/antigravity/scratch/mediai-health-assistant/ml_engine.py)
- Defines 40+ medical conditions, 50+ symptoms, and feature vectors.
- Trains a Scikit-Learn `MultinomialNB` & `RandomForestClassifier` ensemble for probabilistic condition matching.
- Implements `assess_severity(symptoms, severity_rating, duration)` returning Low, Moderate, High, or Emergency risk.
- Implements `check_red_flags(symptoms, severity_rating)` detecting chest pain, respiratory distress, anaphylaxis, etc.
- Implements `evaluate_contraindications(medicines, patient_profile)` checking age, allergies, pregnancy, and chronic conditions.

#### [NEW] [app.py](file:///C:/Users/User/.gemini/antigravity/scratch/mediai-health-assistant/app.py)
- Flask 3.1 server exposing RESTful endpoints:
  - `POST /api/analyze`: Full symptom assessment, condition probability, severity meter, OTC suggestions, and self-care tips.
  - `POST /api/chat`: Conversational NLP assistant with intent recognition and medical guidance.
  - `GET /api/doctors`: Triage specialist directory with booking slots.
  - `GET /api/history`: Past analysis records.
  - `GET /api/system-info`: ML model metrics (accuracy, features, training classes) for academic presentation.
- Serves static assets and the single-page application.

---

### Frontend Application

#### [NEW] [index.html](file:///C:/Users/User/.gemini/antigravity/scratch/mediai-health-assistant/index.html)
- Single-page application containing all 7 core sections:
  1. **Sticky Header & Navigation**: Brand logo with animated AI pulse, navigation links, dark/light theme switch, patient profile indicator, emergency SOS quick trigger.
  2. **Hero & Overview**: High-impact hero section, "Start Health Analysis" and "Talk to MediAI" CTAs, 4 core feature cards, live metric counters.
  3. **Symptom Analysis Form**:
     - Patient profile inputs (Name, Age, Gender, Pregnancy status where applicable).
     - Searchable symptom selector with 20+ preset symptom badges and custom add.
     - Severity 1-10 interactive range slider with dynamic color and status updates.
     - Medical history inputs (Chronic conditions, Current medications, Known allergies).
     - Animated AI Analyzing Scanner modal with multi-step clinical pipeline display.
  4. **AI Health Assessment Result Dashboard**:
     - Symptom summary card.
     - Possible conditions cards with confidence percentages & progress bars.
     - AI Clinical Rationale explanation.
     - Dynamic Risk Meter (🟢 Low / 🟡 Moderate / 🟠 High / 🔴 Emergency).
     - **Print / Download Clinical Health Report** button (generates formatted medical summary).
  5. **Medicine & Self-Care Recommendations**:
     - Safety Check Gate (blocks view if profile missing, triggers 🚨 Urgent Attention if emergency symptoms).
     - Educational OTC medicine cards (Paracetamol, Cetirizine, Antacids, Saline spray, Cough support) with category, purpose, precautions, side effects, and pharmacist warnings.
     - Tailored Self-Care Cards (Hydration, Rest, Diet, Temperature, Tracking, When to call doctor).
  6. **AI Medical Chatbot (MediAI Assistant)**:
     - Sleek conversational view with avatar, typing animation, timestamps.
     - Quick prompt suggestions ("What could cause my headache?", "I have fever and cough", etc.).
  7. **Health History & Analytics Dashboard**:
     - Metric cards: Total analyses, Top symptom, Risk profile, Last checkup.
     - Chart.js timeline showing severity trends over time.
     - Expandable history logs with details modal.
  8. **Doctor Consultation & Triage**:
     - 3-tier triage guide (Monitor at Home / Consult Doctor / Urgent Medical Attention).
     - Doctor appointment booking modal with specialists (Cardiologist, Pulmonologist, ENT, General Physician, etc.).
  9. **AI Technical Workflow & Architecture**:
     - Interactive 9-step ML pipeline visualization for viva/presentation.
  10. **About MediAI & Academic Credentials**:
      - Project mission, team/course info, methodology, and prominent Medical Disclaimer footer.

#### [NEW] [static/js/data.js](file:///C:/Users/User/.gemini/antigravity/scratch/mediai-health-assistant/static/js/data.js)
- Comprehensive dataset of symptoms, symptom descriptions, clinical condition mappings, OTC medicine information, contraindications, and specialist doctor listings.

#### [NEW] [static/js/ai-engine.js](file:///C:/Users/User/.gemini/antigravity/scratch/mediai-health-assistant/static/js/ai-engine.js)
- Client-side AI diagnostic and triage engine matching the backend logic.
- Calculates weighted symptom-condition probability scores, evaluates red flags, calculates risk meters, and performs contraindication filtering.

#### [NEW] [static/js/chatbot.js](file:///C:/Users/User/.gemini/antigravity/scratch/mediai-health-assistant/static/js/chatbot.js)
- Chatbot controller handling message sending, typing delay simulation, intent matching, contextual symptom extraction, and suggested replies.

#### [NEW] [static/js/charts.js](file:///C:/Users/User/.gemini/antigravity/scratch/mediai-health-assistant/static/js/charts.js)
- Chart.js integration for health history trend analytics, risk distribution donut chart, and severity timeline.

#### [NEW] [static/js/app.js](file:///C:/Users/User/.gemini/antigravity/scratch/mediai-health-assistant/static/js/app.js)
- Main application controller: navigation smooth scrolling, dark/light mode toggle with persistence, symptom form validation, tag management, modal handling, local storage persistence, report generation.

#### [NEW] [static/css/custom.css](file:///C:/Users/User/.gemini/antigravity/scratch/mediai-health-assistant/static/css/custom.css)
- Custom glassmorphism, pulse animations, risk meter gradients, dark mode styles, custom range slider, and print stylesheet for printable medical reports.

---

### Project Documentation & Launchers

#### [NEW] [README.md](file:///C:/Users/User/.gemini/antigravity/scratch/mediai-health-assistant/README.md)
- Complete project report, abstract, system architecture, viva question & answer guide, and setup instructions.

#### [NEW] [start_app.bat](file:///C:/Users/User/.gemini/antigravity/scratch/mediai-health-assistant/start_app.bat)
- 1-click batch launcher to start the Flask server and open the browser automatically.

---

## Verification Plan

### Automated & Unit Tests
- Run Python test script to verify `ml_engine.py`:
  - Model training accuracy and probabilistic prediction on test symptom profiles (Fever + Cough + Body Pain; Chest Pain + Shortness of Breath; Acidity + Stomach Pain).
  - Red-flag detection for emergency symptoms.
  - Contraindication safety filter (e.g. Paracetamol warning for liver disease; Aspirin/NSAID allergy checks).
- Run Flask endpoint test (`python -m unittest` or curl tests) verifying `/api/analyze`, `/api/chat`, and `/api/health`.

### Manual & Demonstration Verification
- **Symptom Analysis Flow**: Enter multiple symptom combinations (e.g., Fever + Body Pain -> Viral Fever; Chest Pain + Shortness of Breath -> Emergency Red Flag Trigger).
- **Animated AI Analyzing Screen**: Verify smooth transitions and scanning feedback.
- **Medicine Safety Gate**: Verify missing fields trigger warning, and emergency cases block OTC medication with immediate "Seek Emergency Care" callouts.
- **AI Chatbot**: Test all suggested questions and dynamic symptom queries.
- **Health History & Chart.js**: Add assessments, verify localStorage updates, and observe chart trend updates.
- **Doctor Consultation**: Test doctor specialist filter and simulated appointment booking.
- **Responsive & Dark/Light Mode**: Test theme toggle and mobile responsiveness.
- **Printable Clinical Report**: Test report generation and print layout.
