# Fake Login Page Detection using Machine Learning (with Explainable AI)

A complete web-based cybersecurity application to detect whether a given website URL or login page is **Fake (Phishing / Malicious)** or **Good (Legitimate / Safe)** using a trained Machine Learning model, providing clear explanations of **why** it is classified as fake or good.

---

## 1. Project Overview & Architecture

When users receive suspicious links (via SMS, email, WhatsApp, or search ads), they often cannot tell if the login portal is real or a phishing replica designed to steal credentials. 

This application will provide:
1. **Interactive Cyber Defense Dashboard**: A modern web interface where users can paste any URL or choose from quick sample test cases (legitimate vs phishing).
2. **Machine Learning Classifier**: A Scikit-Learn Random Forest / Gradient Boosting model trained on lexical, domain, and structural URL features to accurately distinguish legitimate login portals from fake phishing clones.
3. **Explainable AI (Why is it Fake? / Why is it Good?)**:
   - **If Fake (Red Flags)**: Highlights exact anomalies such as IP address usage, typosquatting / brand spoofing, excessive subdomains, missing HTTPS, suspicious TLDs (`.tk`, `.xyz`, etc.), obfuscated tokens (`@`, `//`), or deceptive keyword stacking.
   - **If Good (Green Flags)**: Explains trust factors such as authentic domain structure, valid HTTPS protocol, clean URL length, lack of obfuscation, and established top-level domains.
4. **Risk Score & Security Recommendations**: Provides an overall risk probability (0% to 100%), threat severity badge (Safe, Medium Risk, High Threat Phishing), and actionable safety tips.

---

## 2. Technology Stack

- **Backend**: Python 3.13, Flask 3.1
- **Machine Learning**: Scikit-Learn (Random Forest Classifier + Feature Pipelines), NumPy, Pandas, Joblib
- **Frontend**: Responsive HTML5, Tailwind CSS, Lucide Icons, Glassmorphic Cyber-Security UI, Chart/Gauge visualizer
- **Explainability Engine**: Rule-based feature attribution engine mapping model weights and heuristic thresholds to plain-language explanations.

---

## 3. Project Structure

```
C:\Users\User\.gemini\antigravity\scratch\fake-login-detector\
├── app.py                     # Flask web server and API endpoints
├── feature_extractor.py       # 20+ URL lexical, structural, and brand spoofing features + explainability logic
├── train_model.py             # Model training script with benchmark datasets
├── model.joblib               # Serialized trained ML model and metadata
├── requirements.txt           # Python dependencies
├── README.md                  # Project overview, installation, and usage documentation
├── static/
│   ├── css/
│   │   └── style.css          # Custom styling, glow effects, radar animations
│   └── js/
│       └── main.js            # Fetch API, live gauge rendering, breakdown card generator
└── templates/
    └── index.html             # High-tech Cyber Intelligence web UI
```

---

## 4. Proposed Changes & Implementation Steps

### Component 1: Feature Extraction & Explainability Engine (`feature_extractor.py`)
- Extracts 20+ features from any input URL:
  - **Lexical**: URL length, domain length, path length, dot count, hyphen count, numeric characters ratio, `@` symbol presence, double slash `//` redirects.
  - **Structural / Network**: IP address presence in domain, subdomain depth (e.g. `login.bank.com.hacker.com`), suspicious TLD check.
  - **Login / Credential Risk**: Sensitive login keywords in path/subdomain (`login`, `signin`, `verify`, `banking`, `secure`, `update`, `wallet`).
  - **Brand Impersonation**: Typosquatting / homoglyph detection for targeted brands (Google, PayPal, Microsoft, Facebook, Amazon, Netflix, Apple, etc.).
  - **Explainability Function (`explain_prediction`)**:
    - Evaluates each feature against safety baselines.
    - Generates positive points (Green checks: "Valid HTTPS protocol", "Standard domain structure", "No credential harvesting triggers").
    - Generates negative alerts (Red warnings: "IP address detected instead of registered domain", "Brand name used as subdomain to mimic legitimate portal", "High number of subdomains indicating redirection trap").

### Component 2: Machine Learning Pipeline (`train_model.py`)
- Curates a balanced dataset of verified legitimate websites (Alexa top domains, banking portals, verified login URLs) and verified phishing / fake login links (PhishTank / OpenPhish patterns).
- Trains a **Random Forest Classifier** with hyperparameter tuning and calibrated probability output.
- Generates accuracy, precision, recall, and ROC-AUC metrics.
- Exports `model.joblib`.

### Component 3: Flask Web Application (`app.py`)
- Route `/`: Serves the analyzer web interface.
- Route `/api/analyze` (POST): Accepts URL input, extracts features, queries the ML model, calculates confidence score, runs the explainability engine, and returns a JSON payload with:
  - `status`: Safe / Suspicious / Dangerous Phishing
  - `risk_score`: Percentage (0 - 100%)
  - `confidence`: ML model probability
  - `reasons_good`: List of positive safety factors with descriptions
  - `reasons_fake`: List of red flags with risk levels
  - `extracted_features`: Raw feature values for technical inspection
  - `safety_tips`: What the user should do next.

### Component 4: Modern Cybersecurity Dashboard UI (`templates/index.html`, `static/`)
- Dark-mode cyber defense look with glowing neon accents (emerald green for safe, crimson red for fake).
- **Instant Demo Chips**: Quick buttons to test real URLs (e.g. `https://accounts.google.com/signin`, `https://github.com/login`) and simulated phishing URLs (e.g. `http://192.168.1.10/paypal-verify/login.php`, `http://login.apple.id.security-alert-update.tk`).
- **Live Gauge & Threat Meter**: Animated circular score wheel showing risk percentage.
- **Explainability Section**: Side-by-side cards:
  - 🛡️ **Why It Is Good** (Clear green tags explaining verified indicators).
  - ⚠️ **Why It Is Fake** (Clear red tags detailing detected attack vectors).
- **URL Dissector Card**: Shows protocol, domain, subdomains, and path breakdown.

---

## 5. Verification Plan

### Automated Tests
- Run `python train_model.py` and verify model accuracy > 95%.
- Run test assertions across benchmark test cases:
  - Legit: `https://www.google.com`, `https://github.com/login`, `https://www.amazon.com`
  - Phishing: `http://login.paypal.com.account-update.xyz/login.html`, `http://192.168.1.1/secure/bank/`, `http://microsoft-verify-support.top/signin`
- Verify API response structure and correct explainability output.

### Manual Verification
- Launch the Flask app (`python app.py`) on `http://127.0.0.1:5000`.
- Verify the UI in browser:
  - Enter custom URLs and verify immediate analysis.
  - Verify smooth UI animations, threat badges, and detailed explanation text.
  - Test responsiveness on desktop and mobile viewports.
