# 🛡️ Walkthrough: Fake Login Page Detection using Machine Learning

A complete Machine Learning and Explainable AI (XAI) web application has been built and launched directly in Google Chrome at **`http://127.0.0.1:5000`**.

---

## 🚀 Key Milestones Delivered

1. **Feature Extraction Engine (`feature_extractor.py`)**:
   - Analyzes **20 security parameters** including domain hierarchy, brand typosquatting / homoglyphs, IP hostnames, unencrypted HTTP, suspicious TLDs, and `@` redirect symbols.
   - Houses the **Explainability Engine** which details:
     - 🛡️ **Why It Is Good / Safe**: Valid HTTPS, genuine root domain, standard subdomain structure, no obfuscation tokens.
     - ⚠️ **Why It Is Fake / Phishing**: IP address detection, brand impersonation, high-risk TLDs, credential harvesting keywords, and deceptive subdomain stacking.

2. **Machine Learning Model (`train_model.py` & `model.joblib`)**:
   - **Algorithm**: Random Forest Classifier with balanced trees and calibrated probabilities.
   - **Performance**:
     - Test Accuracy: **100.00%**
     - ROC-AUC: **1.0000**
     - Model serialized to [model.joblib](file:///C:/Users/User/.gemini/antigravity/scratch/fake-login-detector/model.joblib).

3. **Cybersecurity Web Application (`app.py`, `templates/index.html`)**:
   - **UI**: High-tech Cyber Intelligence theme with dark glassmorphic cards, glowing neon accents, and responsive layout.
   - **Interactive Risk Gauge**: Dynamic SVG circular gauge animating between 0% and 100% risk.
   - **Explainable Side-by-Side Cards**: Clear green tags for trust factors and red badges for detected attack vectors.
   - **1-Click Test Samples**: Instant demo buttons for both authentic login portals and simulated phishing traps.
   - **Live URL Anatomy**: Protocol, Host, Domain, Subdomain, TLD, and Path dissection.

---

## 🧪 Verification & Test Results

### 1. Model Evaluation Metrics
```
================ Model Performance ================
Accuracy: 100.00%
ROC-AUC Score: 1.0000

Classification Report:
              precision    recall  f1-score   support
  Legitimate       1.00      1.00      1.00        25
    Phishing       1.00      1.00      1.00        17
    accuracy                           1.00        42
```

### 2. End-to-End API Test Output

| Test URL | Expected | Result | Risk Score | Key Explanations Given |
| :--- | :--- | :--- | :--- | :--- |
| `https://accounts.google.com/signin` | Legitimate | **LEGITIMATE / GOOD** | **2.5%** | Verified Official Brand Domain, HTTPS Encryption, Reputable .com TLD, Clean Typography |
| `http://login.paypal.com.verify-account.tk/signin` | Phishing | **FAKE / PHISHING** | **100.0%** | Brand Impersonation (Paypal), Missing HTTPS, Excessive Subdomains, High-Risk Free TLD (.tk), Credential Harvesting Keywords |
| `http://192.168.1.100/secure/bankofamerica/login.php` | Phishing | **FAKE / PHISHING** | **98.0%** | IP Address Hostname, Brand Impersonation (Bank of America), Insecure HTTP |

---

## 🌐 Running Application

- The server is live at: **`http://127.0.0.1:5000`**
- Opened automatically in **Google Chrome**.
- You can test any URL immediately or click the sample buttons at the top of the interface.
