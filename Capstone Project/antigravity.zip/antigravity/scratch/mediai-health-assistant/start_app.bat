@echo off
echo =====================================================================
echo  MediAI - Intelligent Health Assistant
echo  AI-Powered Medical Chatbot for Symptom Analysis & Consultation
echo =====================================================================
echo Starting Flask ML Backend on http://127.0.0.1:5000 ...

start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" "http://127.0.0.1:5000"

python app.py
pause
