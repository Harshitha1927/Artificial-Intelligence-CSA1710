"""
app.py - MediAI Flask Server & REST API
Final-Year Engineering Project
AI-Powered Medical Chatbot for Symptom Analysis and Health Consultation
"""

import os
import json
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory

# Lazy loaded on demand to make server start in milliseconds
_ai_engine = None

def get_ai_engine():
    global _ai_engine
    if _ai_engine is None:
        try:
            from ml_engine import ai_engine
            _ai_engine = ai_engine
        except Exception as e:
            print("Error loading ML engine:", e)
    return _ai_engine


app = Flask(__name__, static_folder="static", template_folder=".")

HISTORY_FILE = os.path.join(os.path.dirname(__file__), "history_data.json")

# Predefined Specialist Doctors Directory for Consultation Module
DOCTORS_DIRECTORY = [
    {
        "id": "doc_1",
        "name": "Dr. Sarah Jenkins, MD",
        "specialty": "General Medicine / Internal Medicine",
        "hospital": "Apex Health Medical Center",
        "experience": "14 years",
        "rating": 4.9,
        "reviews_count": 218,
        "fee": "$45 (Demo)",
        "availability": "Today, 2:30 PM",
        "avatar": "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150&auto=format&fit=crop&q=80",
        "focus_areas": ["Viral Fevers", "Hypertension", "Preventative Care", "Infections"]
    },
    {
        "id": "doc_2",
        "name": "Dr. Marcus Vance, MD, FCCP",
        "specialty": "Pulmonology & Respiratory Medicine",
        "hospital": "Metropolitan Lung Institute",
        "experience": "18 years",
        "rating": 4.95,
        "reviews_count": 340,
        "fee": "$60 (Demo)",
        "availability": "Tomorrow, 10:00 AM",
        "avatar": "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80",
        "focus_areas": ["Bronchitis", "Chronic Cough", "Asthma", "Post-Viral Wheezing"]
    },
    {
        "id": "doc_3",
        "name": "Dr. Elena Rostova, MD, FACC",
        "specialty": "Cardiology",
        "hospital": "Heart & Vascular Specialty Hospital",
        "experience": "16 years",
        "rating": 4.98,
        "reviews_count": 412,
        "fee": "$80 (Demo)",
        "availability": "Today, 4:15 PM",
        "avatar": "https://images.unsplash.com/photo-1594824813576-93d395786576?w=150&auto=format&fit=crop&q=80",
        "focus_areas": ["Chest Pain Triage", "Arrhythmia", "Blood Pressure", "Cardiovascular Risk"]
    },
    {
        "id": "doc_4",
        "name": "Dr. Rajesh K. Patel, MS (ENT)",
        "specialty": "Otolaryngology (ENT Specialist)",
        "hospital": "Sinus & Allergy Care Clinic",
        "experience": "12 years",
        "rating": 4.88,
        "reviews_count": 189,
        "fee": "$50 (Demo)",
        "availability": "Today, 5:00 PM",
        "avatar": "https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80",
        "focus_areas": ["Sinusitis", "Allergic Rhinitis", "Severe Sore Throat", "Tonsillitis"]
    },
    {
        "id": "doc_5",
        "name": "Dr. Christine Lin, MD, FACG",
        "specialty": "Gastroenterology",
        "hospital": "Digestive Health Associates",
        "experience": "15 years",
        "rating": 4.92,
        "reviews_count": 275,
        "fee": "$55 (Demo)",
        "availability": "Tomorrow, 11:30 AM",
        "avatar": "https://images.unsplash.com/photo-1651008376811-b90baee60c1f?w=150&auto=format&fit=crop&q=80",
        "focus_areas": ["Acid Reflux / GERD", "Gastritis", "Abdominal Pain", "IBS"]
    }
]


def load_history():
    """Load stored health assessments from JSON file."""
    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []
    return []


def save_history(history_data):
    """Persist health assessment records."""
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history_data, f, indent=2)
    except Exception as e:
        print("Error saving history:", e)


@app.route("/")
def index():
    """Serve the main application user interface."""
    return send_from_directory(".", "index.html")


@app.route("/static/<path:filename>")
def serve_static(filename):
    """Serve static CSS, JS, and asset files."""
    return send_from_directory("static", filename)


@app.route("/api/health", methods=["GET"])
def health_check():
    """Health check and service status endpoint."""
    return jsonify({
        "status": "healthy",
        "service": "MediAI Health Assistant API",
        "version": "2.4.0",
        "system_time": datetime.now().isoformat()
    })


@app.route("/api/system-info", methods=["GET"])
def system_info():
    """Return machine learning architecture metadata for project viva/presentation."""
    return jsonify({
        "project_title": "AI-Powered Medical Chatbot for Symptom Analysis and Health Consultation",
        "brand_name": "MediAI",
        "engine_type": "Hybrid ML Ensemble & Clinical Decision Support System (CDSS)",
        "models_employed": [
            "Multinomial Naive Bayes (Probabilistic Prior/Posterior Inference)",
            "Random Forest Ensemble (Non-linear multi-symptom correlation)",
            "Clinical Heuristics & Contraindication Safety Filters"
        ],
        "vocabulary_size": 28,
        "condition_classes": 11,
        "features": ["fever", "headache", "cough", "cold", "sore throat", "chest pain", "stomach pain", "vomiting", "diarrhea", "dizziness", "fatigue", "body pain", "shortness of breath", "sneezing", "acidity", "skin rash"],
        "safety_standards": "OTC-only guidelines, Red-flag emergency triage, Contraindication gating"
    })


@app.route("/api/datasets", methods=["GET"])
def get_datasets():
    """Return catalog of project datasets."""
    return jsonify({
        "status": "success",
        "datasets": [
            {"filename": "symptoms_disease_dataset.csv", "name": "Symptom-Disease Training Corpus", "records": 54, "description": "Training combinations mapping multi-symptom profiles to conditions"},
            {"filename": "symptom_severity.csv", "name": "Symptom Severity & Red-Flag Matrix", "records": 24, "description": "Clinical weight matrix from 1-10 with emergency flags"},
            {"filename": "otc_medicines_dataset.csv", "name": "OTC Medicine & Safety Catalog", "records": 6, "description": "Non-prescription medicine guidance with contraindications"},
            {"filename": "disease_precautions.csv", "name": "Disease Self-Care & Referral Guidelines", "records": 11, "description": "Evidence-based supportive care and triage criteria"}
        ]
    })


@app.route("/data/<path:filename>")
def download_data(filename):
    """Serve dataset files for inspection."""
    return send_from_directory("data", filename)


@app.route("/api/analyze", methods=["POST"])
def analyze_symptoms():
    """Perform full AI symptom analysis, condition prediction, and triage."""
    try:
        payload = request.get_json() or {}
        if not payload:
            return jsonify({"error": "No input payload provided"}), 400

        engine = get_ai_engine()
        if engine:
            result = engine.full_assessment(payload)
        else:
            return jsonify({"error": "ML engine initializing"}), 503

        # Append to persistent history
        history = load_history()
        history_item = {
            "id": f"rec_{int(datetime.now().timestamp()*1000)}",
            "date": datetime.now().strftime("%b %d, %Y - %I:%M %p"),
            "patient_name": result["patient"]["name"],
            "symptoms": result["symptoms"]["normalized"],
            "severity_rating": result["patient"]["severity_rating"],
            "top_condition": result["possible_conditions"][0]["condition"] if result["possible_conditions"] else "Non-specific",
            "top_confidence": result["possible_conditions"][0]["confidence"] if result["possible_conditions"] else 50,
            "risk_level": result["risk_meter"]["level"],
            "risk_color": result["risk_meter"]["color"],
            "medicines_suggested": [m["name"] for m in result["medicine_evaluation"].get("medicines", [])],
            "full_result": result
        }
        history.insert(0, history_item)
        save_history(history[:30]) # keep last 30 assessments

        return jsonify({
            "status": "success",
            "data": result,
            "record_id": history_item["id"]
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


@app.route("/api/history", methods=["GET", "DELETE"])
def handle_history():
    """Retrieve or reset assessment records."""
    if request.method == "DELETE":
        save_history([])
        return jsonify({"status": "success", "message": "History successfully cleared"})

    history = load_history()
    return jsonify({
        "status": "success",
        "count": len(history),
        "records": history
    })


@app.route("/api/doctors", methods=["GET"])
def get_doctors():
    """Return available specialist doctors for clinical consultation."""
    specialty_filter = request.args.get("specialty", "").lower()
    if specialty_filter:
        filtered = [d for d in DOCTORS_DIRECTORY if specialty_filter in d["specialty"].lower()]
        return jsonify({"doctors": filtered})
    return jsonify({"doctors": DOCTORS_DIRECTORY})


@app.route("/api/book-consultation", methods=["POST"])
def book_consultation():
    """Handle simulated doctor appointment booking."""
    data = request.get_json() or {}
    doctor_id = data.get("doctor_id")
    patient_name = data.get("patient_name", "Patient")
    preferred_time = data.get("preferred_time", "Next available slot")
    reason = data.get("reason", "Symptom consultation")

    matched_doc = next((d for d in DOCTORS_DIRECTORY if d["id"] == doctor_id), DOCTORS_DIRECTORY[0])

    confirmation = {
        "booking_id": f"MED-APPT-{int(datetime.now().timestamp())}",
        "status": "Confirmed",
        "doctor": matched_doc["name"],
        "specialty": matched_doc["specialty"],
        "hospital": matched_doc["hospital"],
        "patient_name": patient_name,
        "appointment_time": preferred_time,
        "consultation_fee": matched_doc["fee"],
        "instructions": "Please join the video room 5 minutes before scheduled appointment with your recent MediAI Assessment Report."
    }

    return jsonify({"status": "success", "appointment": confirmation})


@app.route("/api/chat", methods=["POST"])
def chat_assistant():
    """Conversational AI Medical Chatbot endpoint."""
    try:
        data = request.get_json() or {}
        user_message = data.get("message", "").strip().lower()

        if not user_message:
            return jsonify({"reply": "Hello! I am your MediAI Health Assistant. How can I assist you today?"})

        # Knowledge-driven conversational responder
        reply = ""
        suggested_queries = []
        requires_analysis = False

        if any(w in user_message for w in ["headache", "head hurt", "migraine"]):
            reply = (
                "Headaches can stem from multiple factors including tension/stress, dehydration, eye strain, lack of sleep, "
                "or sinus pressure. \n\n"
                "💡 **First-line supportive tips:**\n"
                "• Rest in a quiet, dimly lit room\n"
                "• Drink a large glass of water\n"
                "• Apply a cold or warm compress to forehead or temples\n\n"
                "⚠️ **Red Flag Warning:** If you experience a sudden 'thunderclap' headache (worst headache of your life), "
                "stiff neck with fever, or visual disturbances, seek immediate emergency care."
            )
            suggested_queries = ["What medicine helps with mild fever?", "When should I see a doctor?", "Check my headache in Symptom Analysis"]

        elif any(w in user_message for w in ["fever", "temperature", "chills"]):
            reply = (
                "A fever is your body's natural immunological response to fight off infections (most commonly viral or bacterial). \n\n"
                "🌡️ **Helpful Guidelines:**\n"
                "• Stay well-hydrated with water, broths, and electrolyte fluids\n"
                "• Wear loose, lightweight clothing\n"
                "• For mild-to-moderate fever, OTC Paracetamol (Acetaminophen) is commonly used for temporary relief if not contraindicated\n\n"
                "🚨 **When to seek immediate attention:** Temperature exceeding 103°F (39.4°C), fever lasting more than 3 days, or if accompanied by severe breathing difficulty or confusion."
            )
            suggested_queries = ["I have fever and cough. What should I do?", "What medicine information is available for mild fever?", "Start full symptom analysis"]

        elif any(w in user_message for w in ["cough", "sore throat", "cold", "runny nose", "sneezing"]):
            reply = (
                "Cough and cold symptoms are predominantly caused by viral upper respiratory infections. \n\n"
                "💧 **Supportive Care:**\n"
                "• Warm saline gargles (1/2 tsp salt in warm water) 3-4 times daily for sore throat\n"
                "• Warm steam inhalation to loosen nasal mucus\n"
                "• Saline nasal spray to hydrate irritated nasal passages\n"
                "• Honey and warm lemon water for dry cough soothing (for adults and children > 1 year)\n\n"
                "Notice: Antibiotics do **not** work against viral colds and should never be used without a physician's prescription."
            )
            suggested_queries = ["What could cause my headache?", "When should I see a doctor?", "Launch Symptom Analysis"]

        elif any(w in user_message for w in ["dizziness", "dizzy", "lightheaded"]):
            reply = (
                "Dizziness or lightheadedness can arise from dehydration, sudden change in posture (orthostatic hypotension), "
                "inner ear disturbances (vertigo), low blood sugar, or fatigue. \n\n"
                "🧘 **Immediate Actions:**\n"
                "• Sit or lie down immediately to prevent falling\n"
                "• Sip water or an electrolyte beverage\n"
                "• Avoid sudden neck or head movements\n\n"
                "🚨 **Urgent:** If accompanied by chest pain, slurred speech, or weakness in one side of your body, call emergency services immediately."
            )
            suggested_queries = ["What medicine information is available for mild fever?", "Book Doctor Consultation", "When should I see a doctor?"]

        elif any(w in user_message for w in ["when should i see a doctor", "doctor", "consult"]):
            reply = (
                "You should consult a healthcare professional if:\n\n"
                "1. **Symptoms persist** beyond 3 to 5 days without improvement\n"
                "2. **Fever spikes** above 102°F or persists despite fever reducers\n"
                "3. **Pain is severe** (abdomen, chest, or head)\n"
                "4. **You have chronic conditions** (diabetes, asthma, heart disease) or are pregnant\n"
                "5. **Any red-flag symptoms occur:** shortness of breath, sudden numbness, or inability to keep liquids down."
            )
            suggested_queries = ["Talk to MediAI about my symptoms", "Find a Doctor", "Check my risk score"]

        elif any(w in user_message for w in ["medicine", "paracetamol", "cetirizine", "antacid", "pill"]):
            reply = (
                "For common mild symptoms, general over-the-counter (OTC) options include:\n\n"
                "• **Paracetamol:** For mild pain and fever reduction (always check liver health & avoid exceeding daily limits)\n"
                "• **Cetirizine:** For allergic sneezing, runny nose, or mild hives\n"
                "• **Antacids:** For temporary relief of acidity or heartburn\n"
                "• **Saline Nasal Sprays:** For drug-free nasal congestion relief\n\n"
                "⚠️ **Important:** These are general educational descriptions, not prescriptions. Always verify with a doctor or licensed pharmacist before taking any medication."
            )
            suggested_queries = ["I have fever and cough. What should I do?", "What could cause my headache?", "Start Health Analysis"]

        elif any(w in user_message for w in ["chest pain", "shortness of breath", "bleeding", "unconscious", "emergency"]):
            reply = (
                "🚨 **URGENT MEDICAL ATTENTION RECOMMENDED**\n\n"
                "Symptoms such as severe chest pain, acute shortness of breath, loss of consciousness, or severe bleeding "
                "can indicate a life-threatening medical emergency. \n\n"
                "Please call your local emergency services (e.g. 911 / 112 / 108) or go to the nearest emergency room immediately. "
                "Do not attempt self-treatment."
            )
            suggested_queries = ["Find Emergency Medical Help", "Contact Healthcare Professional"]

        else:
            reply = (
                f"Thank you for sharing. I noted your query regarding \"{user_message}\". \n\n"
                "As an AI health assistant, I can help you understand symptoms, review educational OTC medicine information, "
                "and assess clinical risk. For an accurate multi-symptom assessment, I recommend running our interactive "
                "**Symptom Analysis** tool."
            )
            suggested_queries = ["Start Health Analysis", "What could cause my headache?", "What medicine information is available for mild fever?"]
            requires_analysis = True

        return jsonify({
            "status": "success",
            "reply": reply,
            "suggested_queries": suggested_queries,
            "requires_analysis": requires_analysis,
            "timestamp": datetime.now().strftime("%I:%M %p")
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    # Ensure history file exists
    if not os.path.exists(HISTORY_FILE):
        save_history([])
    print("Starting MediAI Server on http://localhost:5000 ...")
    app.run(host="0.0.0.0", port=5000, debug=False)
