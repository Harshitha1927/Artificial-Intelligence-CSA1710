# MediAI Clinical Knowledge Datasets

This directory contains the machine learning training data, clinical symptom severity weights, disease precautions, and educational OTC medicine guidelines for the **MediAI — Intelligent Health Assistant** engineering project.

---

## 📁 Dataset Files Overview

| File Name | Description | Key Features / Columns | Records |
|---|---|---|---|
| **`symptoms_disease_dataset.csv`** | Primary training dataset for Scikit-Learn Bayesian & Random Forest classification | `Disease`, `Symptom_1` to `Symptom_6`, `Severity_Level`, `Emergency_Flag` | 54 symptom combinations across 11 clinical conditions |
| **`symptom_severity.csv`** | Clinical severity weight matrix (1–10 scale) | `Symptom`, `Severity_Weight_1_to_10`, `Category`, `Is_Red_Flag`, `Clinical_Description` | 24 core symptoms |
| **`otc_medicines_dataset.csv`** | Over-the-counter educational medicine and safety database | `Medicine_Name`, `Active_Ingredient`, `Category`, `Target_Symptoms`, `General_Purpose`, `Contraindications`, `Common_Side_Effects`, `Safety_Warnings` | Standard FDA/WHO recognized OTC options |
| **`disease_precautions.csv`** | Evidence-based self-care and medical referral guidelines | `Disease`, `Precaution_1`, `Precaution_2`, `Precaution_3`, `Precaution_4`, `When_To_See_Doctor` | 11 conditions |

---

## 🔬 Dataset Schema & Machine Learning Usage

### 1. `symptoms_disease_dataset.csv`
- **Target Variable**: `Disease` (multi-class clinical condition).
- **Predictor Vectors**: Multi-label binary encoded symptom presence (vectorized via `sklearn.preprocessing.MultiLabelBinarizer`).
- **Algorithms**:
  - `MultinomialNB (alpha=0.6)`: Prior and posterior probabilistic disease likelihood.
  - `RandomForestClassifier (n_estimators=35)`: Non-linear correlation across multi-symptom permutations.

### 2. `symptom_severity.csv`
- Maps each symptom to an anatomical category (Cardiovascular, Respiratory, Gastrointestinal, Neurological, Dermatological, General).
- Flags critical emergency symptoms (`Is_Red_Flag = Yes`) such as `chest pain`, `shortness of breath`, `loss of consciousness`, `severe bleeding`, `sudden weakness`, and `severe allergic reaction`.

### 3. `otc_medicines_dataset.csv`
- Enforces medical ethics guardrails.
- Cross-references patient profile (Age, Chronic Diseases, Known Drug Allergies, Pregnancy status) against `Contraindications` to warn patients against improper self-medication.

---

## 📍 Dataset File Path on Your System
```
C:\Users\User\.gemini\antigravity\scratch\mediai-health-assistant\data\
├── symptoms_disease_dataset.csv
├── symptom_severity.csv
├── otc_medicines_dataset.csv
├── disease_precautions.csv
└── README.md
```
