"""
run.py - Launch MediAI and open in Google Chrome
"""
import os
import subprocess
import threading
import time
import webbrowser
from app import app

def open_browser():
    time.sleep(1.2)
    chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
    url = "http://127.0.0.1:5000"
    if os.path.exists(chrome_path):
        subprocess.Popen([chrome_path, url])
    else:
        webbrowser.open(url)

if __name__ == "__main__":
    print("Launching MediAI - Intelligent Health Assistant...")
    threading.Thread(target=open_browser, daemon=True).start()
    app.run(host="127.0.0.1", port=5000, debug=False)
