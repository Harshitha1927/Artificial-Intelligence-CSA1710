# MediAI — Intelligent Health Assistant
## AI-Powered Medical Chatbot for Symptom Analysis and Health Consultation

> **Final-Year Engineering Project Capstone Demonstration**  
> **Brand Name:** MediAI — Intelligent Health Assistant  
> **Tagline:** “Understand Your Symptoms. Make Better Health Decisions.”

---

## 1. Project Overview & Clinical Objective

**MediAI** is an enterprise-grade Clinical Decision Support System (CDSS) and conversational AI agent designed to bridge the critical gap between initial symptom emergence and formal clinical consultation. 

### Core Objectives
1. **Intelligent Symptom Analysis**: Multi-symptom Bayesian & Random Forest ensemble condition prediction with calibrated confidence scoring.
2. **Dynamic Clinical Severity Stratification**: 4-tier visual risk meter (🟢 Low Risk, 🟡 Moderate Risk, 🟠 High Risk, 🔴 Emergency).
3. **Emergency Red-Flag Detection**: Proactive identification of acute cardiorespiratory crises, stroke warning signs, and severe anaphylaxis.
4. **Educational Medicine Information & Safety Gating**: Non-prescription, OTC-only guidance with contraindication checks (allergies, hepatic/renal conditions, pediatric and pregnancy status).
5. **Conversational Healthcare Bot**: NLP-driven clinical triage assistant with suggested clinical prompts.
6. **Longitudinal Health History**: Interactive Chart.js analytics tracking symptom progression and confidence over time.
7. **Clinical Triage & Consultation**: Evidence-based referral guidelines with specialist doctor booking simulation.

---

## 2. Technical Architecture & Machine Learning Pipeline

```
[User Input & Demographics]
            ↓
   [Data Preprocessing] → Tokenization & MultiLabelBinarizer Vectorization
            ↓
  [Scikit-Learn ML Core] → Multinomial Naive Bayes + Random Forest Ensemble
            ↓
 [Probabilistic Prediction] → Calibrated Confidence Scores (%)
            ↓
   [Clinical Risk Engine] → Dynamic Severity Meter (🟢 🟡 🟠 🔴)
            ↓
[Emergency Red Flag Check] → Acute Cardiorespiratory & Neurological Flags
            ↓
[Safety & Contraindication] → Age, Allergy, Pregnancy & Hepatic Checks
            ↓
  [Educational Guidance] → Non-Prescription OTC Catalog & Self-Care
            ↓
 [Triage & Doctor Booking] → Specialist Matching & Printable Report
```

### Machine Learning Details
- **Feature Space**: 28 normalized clinical symptom vectors.
- **Classification Algorithms**:
  - `MultinomialNB (alpha=0.6)`: Rapid, highly interpretable probabilistic prior/posterior inference.
  - `RandomForestClassifier (n_estimators=35)`: Non-linear feature interaction checking across complex symptom combinations.
- **Safety Rule Layer**: Hard-coded clinical heuristics enforcing medical ethics (OTC-only, no unsupervised antibiotics/steroids, emergency override).

---

## 3. How to Run in Google Chrome

### Option 1: 1-Click Batch File (Recommended)
Double-click `start_app.bat` inside the project folder:
```bash
C:\Users\User\.gemini\antigravity\scratch\mediai-health-assistant\start_app.bat
```

### Option 2: Python Command
Run in PowerShell / Command Prompt:
```powershell
cd C:\Users\User\.gemini\antigravity\scratch\mediai-health-assistant
python run.py
```
This automatically launches the Flask server at `http://localhost:5000` and opens **Google Chrome** immediately.

### Option 3: Direct Browser Launch (Offline Mode)
The application includes a client-side AI diagnostic engine (`static/js/ai-engine.js`). You can open `index.html` directly in Google Chrome without running any server!

---

## 4. Key Demonstration Flows for Faculty

1. **Upper Respiratory Cold Flow**:
   - Primary: `Cold` + Additional: `Sneezing`, `Sore Throat`, `Cough`. Severity: `3/10`.
   - Result: **Common Cold (82% Confidence)**, 🟢 Low Risk.
   - Medicine: Saline Nasal Spray, Cetirizine (OTC only).
2. **Acute Febrile Illness Flow**:
   - Primary: `Fever` + Additional: `Body Pain`, `Headache`, `Chills`. Severity: `5/10`.
   - Result: **Viral Fever (78% Confidence)**, 🟡 Moderate Risk.
   - Medicine: Paracetamol (OTC fever reducer), Temperature tracking card.
3. **Emergency Red Flag Detection Flow**:
   - Primary: `Chest Pain` + Additional: `Shortness of Breath`, `Sweating`. Severity: `9/10`.
   - Result: 🔴 **Emergency Warning Banner** immediately activates! Routine OTC medicine is suppressed; urgent emergency care and doctor hotline are prioritized.
4. **Safety & Contraindication Flow**:
   - Select patient with known **Liver Disease**, then input `Fever`.
   - Notice how MediAI flags Paracetamol with a yellow **Contraindication Caution** tag.
5. **Printable Health Assessment Report**:
   - Click "Print Clinical Report" to view the clean, professional medical document ready for hospital records or PDF export.

---

## 5. Technology Stack
- **Backend**: Python 3.13, Flask 3.1, Scikit-Learn 1.9, NumPy 2.5
- **Frontend**: HTML5, Tailwind CSS, JavaScript (ES6+), Chart.js
- **Design Pattern**: Glassmorphism, Dark/Light mode, Responsive Mobile/Desktop UI
- **Safety Standard**: WHO/FDA OTC educational guidance compliance
