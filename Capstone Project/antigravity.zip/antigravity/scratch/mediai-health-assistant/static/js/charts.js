/**
 * static/js/charts.js
 * Chart.js Integration for MediAI Health History & Analytics
 */

class HealthChartsManager {
  constructor() {
    this.trendChart = null;
    this.riskChart = null;
  }

  init(historyData) {
    this.renderTrendChart(historyData);
    this.renderRiskChart(historyData);
  }

  update(historyData) {
    if (this.trendChart) {
      this.trendChart.destroy();
    }
    if (this.riskChart) {
      this.riskChart.destroy();
    }
    this.renderTrendChart(historyData);
    this.renderRiskChart(historyData);
  }

  renderTrendChart(historyData) {
    const canvas = document.getElementById("historyTrendChart");
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    const isDark = document.documentElement.classList.contains("dark");
    const textColor = isDark ? "#cbd5e1" : "#475569";
    const gridColor = isDark ? "rgba(255, 255, 255, 0.08)" : "rgba(0, 0, 0, 0.06)";

    // Reverse so chronologically left to right
    const records = [...(historyData || [])].reverse().slice(-7);

    const labels = records.map(r => {
      const parts = (r.date || "").split("-");
      return parts[0] ? parts[0].trim() : "Recent";
    });

    const severityData = records.map(r => r.severity_rating || 3);
    const confidenceData = records.map(r => r.top_confidence || 60);

    this.trendChart = new Chart(ctx, {
      type: "line",
      data: {
        labels: labels.length > 0 ? labels : ["No data"],
        datasets: [
          {
            label: "Severity Rating (1-10)",
            data: severityData.length > 0 ? severityData : [3],
            borderColor: "#0284c7",
            backgroundColor: "rgba(2, 132, 199, 0.15)",
            tension: 0.35,
            fill: true,
            pointBackgroundColor: "#0284c7",
            pointRadius: 5,
            pointHoverRadius: 7,
            yAxisID: "y"
          },
          {
            label: "AI Confidence (%)",
            data: confidenceData.length > 0 ? confidenceData : [75],
            borderColor: "#0d9488",
            borderDash: [5, 5],
            backgroundColor: "transparent",
            tension: 0.35,
            pointBackgroundColor: "#0d9488",
            pointRadius: 4,
            yAxisID: "y1"
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: "index",
          intersect: false
        },
        plugins: {
          legend: {
            position: "top",
            labels: {
              color: textColor,
              font: { family: "'Inter', sans-serif", size: 12, weight: 500 }
            }
          },
          tooltip: {
            padding: 12,
            backgroundColor: isDark ? "#1e293b" : "#ffffff",
            titleColor: isDark ? "#f8fafc" : "#0f172a",
            bodyColor: isDark ? "#e2e8f0" : "#334155",
            borderColor: isDark ? "#334155" : "#e2e8f0",
            borderWidth: 1
          }
        },
        scales: {
          x: {
            grid: { color: gridColor },
            ticks: { color: textColor, font: { family: "'Inter', sans-serif", size: 11 } }
          },
          y: {
            type: "linear",
            display: true,
            position: "left",
            min: 0,
            max: 10,
            grid: { color: gridColor },
            ticks: { color: textColor, stepSize: 2 },
            title: {
              display: true,
              text: "Severity Level",
              color: textColor,
              font: { size: 11 }
            }
          },
          y1: {
            type: "linear",
            display: true,
            position: "right",
            min: 0,
            max: 100,
            grid: { drawOnChartArea: false },
            ticks: { color: textColor, stepSize: 25 },
            title: {
              display: true,
              text: "Confidence %",
              color: textColor,
              font: { size: 11 }
            }
          }
        }
      }
    });
  }

  renderRiskChart(historyData) {
    const canvas = document.getElementById("riskDistributionChart");
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    const isDark = document.documentElement.classList.contains("dark");
    const textColor = isDark ? "#cbd5e1" : "#475569";

    const counts = { Low: 0, Moderate: 0, High: 0, Emergency: 0 };
    (historyData || []).forEach(r => {
      const lvl = (r.risk_level || "").toLowerCase();
      if (lvl.includes("low")) counts.Low++;
      else if (lvl.includes("mod")) counts.Moderate++;
      else if (lvl.includes("high")) counts.High++;
      else if (lvl.includes("emerg")) counts.Emergency++;
      else counts.Low++;
    });

    if (Object.values(counts).every(v => v === 0)) {
      counts.Low = 1;
      counts.Moderate = 1;
    }

    this.riskChart = new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: ["Low Risk", "Moderate Risk", "High Risk", "Emergency"],
        datasets: [{
          data: [counts.Low, counts.Moderate, counts.High, counts.Emergency],
          backgroundColor: ["#10b981", "#eab308", "#f97316", "#ef4444"],
          borderWidth: 2,
          borderColor: isDark ? "#0f172a" : "#ffffff",
          hoverOffset: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "bottom",
            labels: {
              color: textColor,
              boxWidth: 12,
              font: { family: "'Inter', sans-serif", size: 11 }
            }
          }
        },
        cutout: "68%"
      }
    });
  }
}

window.healthChartsManager = new HealthChartsManager();
