/**
 * static/js/data.js
 * Medical Knowledge Base, Symptom Definitions, OTC Medicines, and Consultation Data
 * MediAI — Intelligent Health Assistant
 */

const SYMPTOM_LIST = [
  { id: "fever", name: "Fever", icon: "🌡️", category: "General", desc: "Elevated body temperature above 98.6°F (37°C)" },
  { id: "headache", name: "Headache", icon: "🤕", category: "Neurological", desc: "Pain or throbbing sensation in head or temples" },
  { id: "cough", name: "Cough", icon: "🗣️", category: "Respiratory", desc: "Sudden expulsion of air from lungs; dry or productive" },
  { id: "cold", name: "Cold / Congestion", icon: "🤧", category: "Respiratory", desc: "Stuffy or blocked nasal passages" },
  { id: "sore throat", name: "Sore Throat", icon: "🧣", category: "ENT", desc: "Pain, scratchiness or irritation of the throat" },
  { id: "chest pain", name: "Chest Pain", icon: "💔", category: "Cardiac / Emergency", desc: "Discomfort or tightness in chest area (Red Flag)" },
  { id: "stomach pain", name: "Stomach Pain", icon: "🤢", category: "Gastrointestinal", desc: "Abdominal cramping, aching, or sharp pain" },
  { id: "vomiting", name: "Vomiting", icon: "🤮", category: "Gastrointestinal", desc: "Involuntary ejection of stomach contents" },
  { id: "diarrhea", name: "Diarrhea", icon: "🚽", category: "Gastrointestinal", desc: "Frequent, loose, or watery bowel movements" },
  { id: "dizziness", name: "Dizziness", icon: "💫", category: "Neurological", desc: "Lightheadedness, unsteadiness, or vertigo" },
  { id: "fatigue", name: "Fatigue", icon: "🥱", category: "General", desc: "Extreme tiredness, low energy, lethargy" },
  { id: "body pain", name: "Body Pain / Myalgia", icon: "⚡", category: "Musculoskeletal", desc: "Generalized muscle and joint ache" },
  { id: "shortness of breath", name: "Shortness of Breath", icon: "🫁", category: "Respiratory / Emergency", desc: "Difficulty breathing, labored respiration (Red Flag)" },
  { id: "sneezing", name: "Sneezing", icon: "🤧", category: "Allergy", desc: "Involuntary expulsion of air from nose" },
  { id: "acidity", name: "Acidity / Heartburn", icon: "🔥", category: "Gastrointestinal", desc: "Burning sensation in upper chest or esophagus" },
  { id: "skin rash", name: "Skin Rash", icon: "🔴", category: "Dermatological", desc: "Redness, bumps, itching, or hives on skin" },
  { id: "chills", name: "Chills", icon: "🥶", category: "General", desc: "Shivering sensations often preceding fever" },
  { id: "nausea", name: "Nausea", icon: "🤢", category: "Gastrointestinal", desc: "Queasy feeling in the stomach with urge to vomit" },
  { id: "wheezing", name: "Wheezing", icon: "🌬️", category: "Respiratory", desc: "High-pitched whistling sound during breathing" },
  { id: "difficulty swallowing", name: "Difficulty Swallowing", icon: "🍷", category: "ENT", desc: "Painful or difficult food/liquid passage" }
];

const CHRONIC_CONDITIONS_LIST = [
  "Hypertension (High BP)",
  "Type 2 Diabetes",
  "Asthma / COPD",
  "Coronary Artery Disease",
  "Chronic Kidney Disease",
  "Liver Disease / Hepatitis",
  "Thyroid Disorder",
  "Gastroesophageal Reflux (GERD)"
];

const COMMON_ALLERGIES_LIST = [
  "Penicillin / Amoxicillin",
  "Sulfa Drugs (Sulfonamides)",
  "Aspirin / NSAIDs (Ibuprofen)",
  "Latex",
  "Peanuts / Tree Nuts",
  "Dairy / Lactose",
  "No Known Drug Allergies (NKDA)"
];

const INITIAL_HEALTH_HISTORY = [
  {
    id: "rec_1001",
    date: "Aug 26, 2026 - 10:15 AM",
    patient_name: "Demo Patient",
    symptoms: ["sneezing", "cold", "sore throat"],
    severity_rating: 3,
    top_condition: "Common Cold",
    top_confidence: 82,
    risk_level: "Low Risk",
    risk_color: "#10b981",
    medicines_suggested: ["Saline Nasal Spray (0.9% Sodium Chloride)", "Cetirizine / Loratadine"]
  },
  {
    id: "rec_1002",
    date: "Aug 29, 2026 - 04:40 PM",
    patient_name: "Demo Patient",
    symptoms: ["acidity", "stomach pain"],
    severity_rating: 4,
    top_condition: "Acid Reflux (GERD)",
    top_confidence: 76,
    risk_level: "Low Risk",
    risk_color: "#10b981",
    medicines_suggested: ["Antacid (Magnesium/Aluminum Hydroxide)"]
  },
  {
    id: "rec_1003",
    date: "Sep 01, 2026 - 02:20 PM",
    patient_name: "Demo Patient",
    symptoms: ["fever", "body pain", "fatigue"],
    severity_rating: 5,
    top_condition: "Viral Fever",
    top_confidence: 74,
    risk_level: "Moderate Risk",
    risk_color: "#eab308",
    medicines_suggested: ["Paracetamol / Acetaminophen"]
  }
];

// Export to global window context for easy access
window.MediAIData = {
  SYMPTOM_LIST,
  CHRONIC_CONDITIONS_LIST,
  COMMON_ALLERGIES_LIST,
  INITIAL_HEALTH_HISTORY
};
