/**
 * static/js/app.js
 * MediAI — Intelligent Health Assistant
 * Main Application Controller & UI Logic
 */

document.addEventListener("DOMContentLoaded", () => {
  // 1. Initialize Theme (Dark / Light Mode)
  initTheme();

  // 2. State & Storage Initialization
  initAppState();

  // 3. Populate Symptom Selector & Options
  initSymptomSelector();
  initFormControls();

  // 4. Attach Form Submission & Analysis Workflow
  initAnalysisForm();

  // 5. Initialize Doctor Directory & Booking
  initDoctorConsultation();

  // 6. Initialize History & Charts
  loadHealthHistory();

  // 7. Initialize Chatbot
  if (window.MediAIChatbot) {
    window.mediAIChatbot = new MediAIChatbot();
  }

  // 8. Navigation & Smooth Scrolling
  initNavigation();
});

/* ============================================================
   THEME MANAGER
   ============================================================ */
function initTheme() {
  const themeToggleBtn = document.getElementById("theme-toggle-btn");
  const themeIcon = document.getElementById("theme-toggle-icon");
  const savedTheme = localStorage.getItem("mediai_theme") || "light";

  if (savedTheme === "dark") {
    document.documentElement.classList.add("dark");
    if (themeIcon) themeIcon.textContent = "☀️";
  } else {
    document.documentElement.classList.remove("dark");
    if (themeIcon) themeIcon.textContent = "🌙";
  }

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener("click", () => {
      const isDark = document.documentElement.classList.toggle("dark");
      localStorage.setItem("mediai_theme", isDark ? "dark" : "light");
      if (themeIcon) themeIcon.textContent = isDark ? "☀️" : "🌙";
      // Refresh charts for theme contrast
      if (window.healthChartsManager && window.currentHistoryData) {
        window.healthChartsManager.update(window.currentHistoryData);
      }
    });
  }
}

/* ============================================================
   APP STATE & STORAGE
   ============================================================ */
let selectedSymptoms = new Set();
let selectedConditions = new Set();
let selectedAllergies = new Set();
let latestAssessment = null;

function initAppState() {
  // Load sample history if empty in localStorage
  if (!localStorage.getItem("mediai_history")) {
    localStorage.setItem("mediai_history", JSON.stringify(window.MediAIData.INITIAL_HEALTH_HISTORY));
  }
}

/* ============================================================
   SYMPTOM SELECTOR & FORM CONTROLS
   ============================================================ */
function initSymptomSelector() {
  const container = document.getElementById("symptom-badges-container");
  const searchInput = document.getElementById("symptom-search-input");
  const mainSymptomSelect = document.getElementById("main-symptom-select");

  if (!container || !window.MediAIData) return;

  const symptoms = window.MediAIData.SYMPTOM_LIST;

  // Populate main symptom dropdown
  if (mainSymptomSelect) {
    mainSymptomSelect.innerHTML = '<option value="">-- Select Primary Symptom --</option>' +
      symptoms.map(s => `<option value="${s.name.toLowerCase()}">${s.icon} ${s.name}</option>`).join("");
  }

  // Render clickable symptom badges
  function renderBadges(filter = "") {
    container.innerHTML = "";
    const cleanFilter = filter.toLowerCase().trim();

    symptoms.forEach(sym => {
      if (cleanFilter && !sym.name.toLowerCase().includes(cleanFilter) && !sym.desc.toLowerCase().includes(cleanFilter)) {
        return;
      }

      const isSelected = selectedSymptoms.has(sym.name.toLowerCase());
      const badge = document.createElement("button");
      badge.type = "button";
      badge.className = `px-3 py-1.5 rounded-full text-xs sm:text-sm font-medium transition flex items-center gap-1.5 border ${
        isSelected
          ? "bg-blue-600 text-white border-blue-600 shadow-sm"
          : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:border-blue-400 dark:hover:border-teal-400"
      }`;
      badge.innerHTML = `<span>${sym.icon}</span> <span>${sym.name}</span>`;

      badge.addEventListener("click", () => {
        const id = sym.name.toLowerCase();
        if (selectedSymptoms.has(id)) {
          selectedSymptoms.delete(id);
        } else {
          selectedSymptoms.add(id);
        }
        updateSelectedSymptomsUI();
        renderBadges(searchInput.value);
      });

      container.appendChild(badge);
    });
  }

  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      renderBadges(e.target.value);
    });
  }

  renderBadges();
}

function updateSelectedSymptomsUI() {
  const selectedDisplay = document.getElementById("selected-symptoms-chips");
  const countBadge = document.getElementById("selected-symptoms-count");

  if (countBadge) {
    countBadge.textContent = `${selectedSymptoms.size} selected`;
  }

  if (!selectedDisplay) return;

  selectedDisplay.innerHTML = "";
  if (selectedSymptoms.size === 0) {
    selectedDisplay.innerHTML = '<span class="text-xs text-slate-400 italic">No additional symptoms picked yet.</span>';
    return;
  }

  selectedSymptoms.forEach(symName => {
    const chip = document.createElement("span");
    chip.className = "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-200 border border-blue-200 dark:border-blue-800";
    chip.innerHTML = `
      <span>${symName}</span>
      <button type="button" class="hover:text-red-500 transition font-bold" data-sym="${symName}">×</button>
    `;
    chip.querySelector("button").addEventListener("click", () => {
      selectedSymptoms.delete(symName);
      updateSelectedSymptomsUI();
      initSymptomSelector();
    });
    selectedDisplay.appendChild(chip);
  });
}

function initFormControls() {
  // Severity Slider
  const slider = document.getElementById("severity-slider");
  const valueDisplay = document.getElementById("severity-val-display");
  const labelDisplay = document.getElementById("severity-label-display");

  if (slider && valueDisplay && labelDisplay) {
    const updateSlider = () => {
      const val = parseInt(slider.value, 10);
      valueDisplay.textContent = val;

      if (val <= 3) {
        labelDisplay.textContent = "Mild (Noticeable but does not restrict normal activities)";
        labelDisplay.className = "text-xs font-semibold text-emerald-600 dark:text-emerald-400";
      } else if (val <= 6) {
        labelDisplay.textContent = "Moderate (Discomfort interferes with work or rest)";
        labelDisplay.className = "text-xs font-semibold text-amber-600 dark:text-amber-400";
      } else if (val <= 8) {
        labelDisplay.textContent = "Severe (Substantial pain or distress; medical advice advised)";
        labelDisplay.className = "text-xs font-semibold text-orange-600 dark:text-orange-400";
      } else {
        labelDisplay.textContent = "Critical / Emergency (Intense distress; seek immediate attention)";
        labelDisplay.className = "text-xs font-semibold text-red-600 dark:text-red-400 font-bold animate-pulse";
      }
    };

    slider.addEventListener("input", updateSlider);
    updateSlider();
  }

  // Gender select -> toggle pregnancy
  const genderSelect = document.getElementById("patient-gender");
  const pregnancyWrapper = document.getElementById("pregnancy-status-wrapper");

  if (genderSelect && pregnancyWrapper) {
    genderSelect.addEventListener("change", () => {
      if (genderSelect.value.toLowerCase() === "female") {
        pregnancyWrapper.classList.remove("hidden");
      } else {
        pregnancyWrapper.classList.add("hidden");
        const pregInput = document.getElementById("patient-pregnancy");
        if (pregInput) pregInput.checked = false;
      }
    });
  }

  // Chronic Conditions badges
  const conditionsBox = document.getElementById("chronic-conditions-box");
  if (conditionsBox && window.MediAIData) {
    conditionsBox.innerHTML = window.MediAIData.CHRONIC_CONDITIONS_LIST.map(cond => `
      <label class="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition">
        <input type="checkbox" value="${cond}" class="chronic-checkbox rounded text-blue-600 focus:ring-0">
        <span>${cond}</span>
      </label>
    `).join("");
  }

  // Allergies badges
  const allergiesBox = document.getElementById("allergies-box");
  if (allergiesBox && window.MediAIData) {
    allergiesBox.innerHTML = window.MediAIData.COMMON_ALLERGIES_LIST.map(allergy => `
      <label class="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition">
        <input type="checkbox" value="${allergy}" class="allergy-checkbox rounded text-blue-600 focus:ring-0">
        <span>${allergy}</span>
      </label>
    `).join("");
  }
}

/* ============================================================
   AI ANALYSIS WORKFLOW & ANIMATED SCANNER
   ============================================================ */
function initAnalysisForm() {
  const form = document.getElementById("symptom-analysis-form");
  const modal = document.getElementById("analyzing-modal");
  const progressText = document.getElementById("scanner-step-text");

  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const patientName = document.getElementById("patient-name")?.value.trim() || "Patient";
    const age = document.getElementById("patient-age")?.value.trim();
    const gender = document.getElementById("patient-gender")?.value || "Not specified";
    const mainSymptom = document.getElementById("main-symptom-select")?.value || "";
    const duration = document.getElementById("symptom-duration")?.value || "1-3 days";
    const severityRating = parseInt(document.getElementById("severity-slider")?.value || "4", 10);
    const isPregnant = document.getElementById("patient-pregnancy")?.checked || false;
    const currentMeds = document.getElementById("patient-medications")?.value.trim() || "";

    // Collect checkboxes
    const existingConditions = [];
    document.querySelectorAll(".chronic-checkbox:checked").forEach(cb => existingConditions.push(cb.value));

    const allergies = [];
    document.querySelectorAll(".allergy-checkbox:checked").forEach(cb => allergies.push(cb.value));
    const allergiesProvided = allergies.length > 0;

    const additionalSymptoms = Array.from(selectedSymptoms);

    if (!mainSymptom && additionalSymptoms.length === 0) {
      alert("Please select at least a main symptom or add symptoms to analyze.");
      return;
    }

    const payload = {
      patient_name: patientName,
      age: age ? parseInt(age, 10) : null,
      gender: gender,
      main_symptom: mainSymptom,
      additional_symptoms: additionalSymptoms,
      duration: duration,
      severity_rating: severityRating,
      existing_conditions: existingConditions,
      current_medications: currentMeds,
      allergies: allergies,
      allergies_provided: allergiesProvided,
      is_pregnant: isPregnant
    };

    // Show high-tech clinical scanner modal
    if (modal) modal.classList.remove("hidden");

    const steps = [
      "Standardizing clinical terminology & vectorizing symptoms...",
      "Executing Scikit-Learn Bayesian & Random Forest classifier...",
      "Evaluating red-flag cardiorespiratory emergency criteria...",
      "Analyzing OTC safety profiles & contraindication matrix...",
      "Synthesizing personalized AI Health Assessment..."
    ];

    for (let i = 0; i < steps.length; i++) {
      if (progressText) progressText.textContent = steps[i];
      await new Promise(r => setTimeout(r, 260));
    }

    // Try backend API first, fallback to client-side engine
    let assessmentResult = null;
    try {
      const resp = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (resp.ok) {
        const json = await resp.json();
        assessmentResult = json.data;
      }
    } catch (err) {
      console.warn("Backend API unavailable, using Client AI Engine.", err);
    }

    if (!assessmentResult && window.clientAIEngine) {
      assessmentResult = window.clientAIEngine.analyze(payload);
    }

    // Hide scanner modal
    if (modal) modal.classList.add("hidden");

    latestAssessment = assessmentResult;
    renderAssessmentDashboard(assessmentResult);

    // Save locally & reload history
    saveAssessmentLocally(assessmentResult);
    loadHealthHistory();

    // Scroll smoothly to result dashboard
    const resultSection = document.getElementById("result-section");
    if (resultSection) {
      resultSection.classList.remove("hidden");
      resultSection.scrollIntoView({ behavior: "smooth" });
    }
  });
}

function saveAssessmentLocally(assessment) {
  const history = JSON.parse(localStorage.getItem("mediai_history") || "[]");
  const newRecord = {
    id: `rec_${Date.now()}`,
    date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) + " - " +
          new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    patient_name: assessment.patient.name,
    symptoms: assessment.symptoms.normalized,
    severity_rating: assessment.patient.severity_rating,
    top_condition: assessment.possible_conditions[0]?.condition || "Non-specific",
    top_confidence: assessment.possible_conditions[0]?.confidence || 60,
    risk_level: assessment.risk_meter.level,
    risk_color: assessment.risk_meter.color,
    medicines_suggested: assessment.medicine_evaluation?.medicines?.map(m => m.name) || []
  };

  history.unshift(newRecord);
  localStorage.setItem("mediai_history", JSON.stringify(history.slice(0, 20)));
}

/* ============================================================
   AI RESULT DASHBOARD RENDERING
   ============================================================ */
function renderAssessmentDashboard(data) {
  const container = document.getElementById("result-section");
  if (!container || !data) return;

  // 1. Red Flag Alert Banner (Emergency Warning)
  const emergencyBanner = document.getElementById("emergency-alert-banner");
  const emergencyReasons = document.getElementById("emergency-reasons-list");
  if (emergencyBanner && emergencyReasons) {
    if (data.red_flags && data.red_flags.length > 0) {
      emergencyBanner.classList.remove("hidden");
      emergencyReasons.innerHTML = data.red_flags.map(f => `
        <li class="flex items-start gap-2">
          <span class="text-red-500 font-bold">•</span>
          <div>
            <strong class="text-red-900 dark:text-red-200">${f.symptom}:</strong>
            <span class="text-red-800/90 dark:text-red-300 text-sm">${f.warning}</span>
          </div>
        </li>
      `).join("");
    } else {
      emergencyBanner.classList.add("hidden");
    }
  }

  // 2. Patient & Symptom Summary
  const pName = document.getElementById("res-patient-name");
  const pMeta = document.getElementById("res-patient-meta");
  const symTags = document.getElementById("res-symptoms-tags");

  if (pName) pName.textContent = data.patient.name;
  if (pMeta) {
    pMeta.textContent = `Age: ${data.patient.age || "N/A"} • Gender: ${data.patient.gender} • Duration: ${data.patient.duration}`;
  }

  if (symTags) {
    symTags.innerHTML = data.symptoms.normalized.map(s => `
      <span class="px-2.5 py-1 rounded-md text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 capitalize">
        ${s}
      </span>
    `).join("");
  }

  // 3. Risk Meter
  const riskBadge = document.getElementById("res-risk-badge");
  const riskBar = document.getElementById("res-risk-bar");
  const riskDesc = document.getElementById("res-risk-desc");

  if (riskBadge) {
    riskBadge.textContent = data.risk_meter.badge;
    riskBadge.style.backgroundColor = data.risk_meter.color + "20";
    riskBadge.style.color = data.risk_meter.color;
    riskBadge.style.borderColor = data.risk_meter.color;
  }

  if (riskBar) {
    riskBar.style.width = `${data.risk_meter.score}%`;
    riskBar.style.backgroundColor = data.risk_meter.color;
  }

  if (riskDesc) {
    riskDesc.textContent = data.risk_meter.message;
  }

  // 4. Possible Conditions with Confidence
  const condContainer = document.getElementById("res-conditions-container");
  if (condContainer) {
    condContainer.innerHTML = data.possible_conditions.map((cond, idx) => `
      <div class="p-4 rounded-xl border ${idx === 0 ? "border-blue-300 dark:border-blue-700 bg-blue-50/40 dark:bg-blue-950/20" : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/60"} transition">
        <div class="flex items-center justify-between mb-2">
          <div class="flex items-center gap-2">
            ${idx === 0 ? '<span class="px-2 py-0.5 text-[10px] font-bold uppercase rounded bg-blue-600 text-white">Top Match</span>' : ''}
            <h4 class="font-bold text-slate-800 dark:text-white text-base">${cond.condition}</h4>
          </div>
          <span class="text-sm font-bold text-blue-600 dark:text-teal-400">${cond.confidence}% Confidence</span>
        </div>
        <div class="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2 mb-2.5 overflow-hidden">
          <div class="bg-gradient-to-r from-blue-600 to-teal-500 h-2 rounded-full transition-all duration-700" style="width: ${cond.confidence}%"></div>
        </div>
        <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">${cond.description}</p>
      </div>
    `).join("");
  }

  // 5. AI Explanation
  const aiExp = document.getElementById("res-ai-explanation");
  if (aiExp) {
    aiExp.textContent = data.ai_explanation;
  }

  // 6. Medicine Safety Gate & Recommendations
  renderMedicineRecommendations(data.medicine_evaluation);

  // 7. Self Care Recommendations
  const selfCareContainer = document.getElementById("res-selfcare-container");
  if (selfCareContainer) {
    selfCareContainer.innerHTML = data.self_care_recommendations.map(sc => `
      <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/80 shadow-sm flex items-start gap-3">
        <span class="text-2xl shrink-0">${sc.icon}</span>
        <div>
          <h5 class="font-semibold text-slate-800 dark:text-white text-sm mb-1">${sc.title}</h5>
          <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">${sc.detail}</p>
        </div>
      </div>
    `).join("");
  }
}

function renderMedicineRecommendations(medEval) {
  const alertBox = document.getElementById("medicine-safety-alert");
  const medCardsContainer = document.getElementById("medicine-cards-container");
  const blockedMessage = document.getElementById("medicine-blocked-message");

  if (!medEval) return;

  if (medEval.blocked) {
    if (alertBox) {
      alertBox.classList.remove("hidden");
      alertBox.innerHTML = `
        <div class="p-4 rounded-xl border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/30 text-red-900 dark:text-red-200">
          <h4 class="font-bold text-base flex items-center gap-2 mb-1">${medEval.alert_title || "🚨 Urgent Notice"}</h4>
          <p class="text-sm leading-relaxed">${medEval.alert_message}</p>
          <div class="mt-3 flex gap-3">
            <button onclick="document.getElementById('nav-doctors-btn').click()" class="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold transition flex items-center gap-1.5 shadow">
              <span>👨‍⚕️</span> Find Medical Help Immediately
            </button>
          </div>
        </div>
      `;
    }
    if (medCardsContainer) medCardsContainer.innerHTML = "";
    return;
  }

  if (alertBox) alertBox.classList.add("hidden");

  if (!medCardsContainer) return;

  if (!medEval.medicines || medEval.medicines.length === 0) {
    medCardsContainer.innerHTML = `
      <div class="col-span-full p-6 text-center rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 text-sm">
        No routine OTC medication indicated for the reported mild symptoms. Supportive hydration and rest are prioritized.
      </div>
    `;
    return;
  }

  medCardsContainer.innerHTML = medEval.medicines.map(med => `
    <div class="p-5 rounded-xl border ${med.is_contraindicated ? "border-amber-400 dark:border-amber-600 bg-amber-50/40 dark:bg-amber-950/20" : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/90"} shadow-sm flex flex-col justify-between">
      <div>
        <div class="flex items-start justify-between gap-2 mb-2">
          <div>
            <span class="text-[11px] font-semibold text-blue-600 dark:text-teal-400 uppercase tracking-wider">${med.category}</span>
            <h4 class="font-bold text-slate-900 dark:text-white text-base">${med.name}</h4>
          </div>
          <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">OTC</span>
        </div>

        ${med.is_contraindicated ? `
          <div class="mb-3 p-2.5 rounded-lg bg-amber-100 dark:bg-amber-900/40 border border-amber-300 dark:border-amber-700 text-amber-900 dark:text-amber-200 text-xs font-medium">
            ⚠️ <strong>Contraindication Caution:</strong> ${med.contraindication_warning}
          </div>
        ` : ''}

        <div class="space-y-2 text-xs text-slate-600 dark:text-slate-300 mb-4">
          <p><strong class="text-slate-800 dark:text-slate-200">General Purpose:</strong> ${med.general_purpose}</p>
          <p><strong class="text-slate-800 dark:text-slate-200">Precautions:</strong> ${med.precautions}</p>
          <p><strong class="text-slate-800 dark:text-slate-200">Common Side Effects:</strong> ${med.side_effects}</p>
        </div>

        ${med.special_warnings && med.special_warnings.length > 0 ? `
          <div class="mb-3 p-2 rounded bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-blue-800 dark:text-blue-300 text-[11px]">
            ${med.special_warnings.join("<br>")}
          </div>
        ` : ''}
      </div>

      <div class="pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
        <span>⚠️ Non-prescription info only</span>
        <button onclick="document.getElementById('nav-doctors-btn').click()" class="text-blue-600 dark:text-teal-400 hover:underline font-medium">
          Consult Pharmacist →
        </button>
      </div>
    </div>
  `).join("");
}

/* ============================================================
   HEALTH HISTORY & CHART.JS ANALYTICS
   ============================================================ */
function loadHealthHistory() {
  const history = JSON.parse(localStorage.getItem("mediai_history") || "[]");
  window.currentHistoryData = history;

  // 1. Update Metrics Cards
  const totalCountElem = document.getElementById("stat-total-analyses");
  const topSymptomElem = document.getElementById("stat-common-symptom");
  const currentRiskElem = document.getElementById("stat-current-risk");
  const lastDateElem = document.getElementById("stat-last-analysis");

  if (totalCountElem) totalCountElem.textContent = history.length;

  if (history.length > 0) {
    // Find most common symptom
    const symCount = {};
    history.forEach(r => {
      (r.symptoms || []).forEach(s => {
        symCount[s] = (symCount[s] || 0) + 1;
      });
    });
    const sorted = Object.entries(symCount).sort((a, b) => b[1] - a[1]);
    if (topSymptomElem) topSymptomElem.textContent = sorted[0] ? sorted[0][0].charAt(0).toUpperCase() + sorted[0][0].slice(1) : "None";

    if (currentRiskElem) {
      currentRiskElem.textContent = history[0].risk_level;
      currentRiskElem.style.color = history[0].risk_color || "#0284c7";
    }

    if (lastDateElem) {
      lastDateElem.textContent = (history[0].date || "").split("-")[0].trim();
    }
  }

  // 2. Render History Cards Table
  const tableBody = document.getElementById("history-records-list");
  if (tableBody) {
    if (history.length === 0) {
      tableBody.innerHTML = `
        <div class="p-8 text-center text-slate-400 text-sm italic">
          No previous health assessments recorded yet. Run your first analysis above!
        </div>
      `;
    } else {
      tableBody.innerHTML = history.map(rec => `
        <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/90 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div class="space-y-1">
            <div class="flex items-center gap-2">
              <span class="text-xs text-slate-400">${rec.date}</span>
              <span class="px-2 py-0.5 rounded-full text-[11px] font-bold text-white" style="background-color: ${rec.risk_color || '#0284c7'}">
                ${rec.risk_level}
              </span>
            </div>
            <h4 class="font-bold text-slate-800 dark:text-white text-base">${rec.top_condition} (${rec.top_confidence || 75}%)</h4>
            <div class="flex flex-wrap gap-1">
              ${(rec.symptoms || []).map(s => `<span class="text-[11px] bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded">${s}</span>`).join("")}
            </div>
          </div>

          <div class="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
            <span class="text-xs text-slate-500 dark:text-slate-400">Severity: <strong>${rec.severity_rating}/10</strong></span>
            <button onclick="viewHistoryDetail('${rec.id}')" class="px-3 py-1.5 rounded-lg border border-blue-200 dark:border-slate-600 text-xs font-semibold text-blue-600 dark:text-teal-300 hover:bg-blue-50 dark:hover:bg-slate-700 transition">
              View Details
            </button>
          </div>
        </div>
      `).join("");
    }
  }

  // 3. Render Chart.js
  if (window.healthChartsManager) {
    window.healthChartsManager.init(history);
  }
}

window.viewHistoryDetail = function(recId) {
  const history = JSON.parse(localStorage.getItem("mediai_history") || "[]");
  const rec = history.find(r => r.id === recId);
  if (!rec) return;

  const modal = document.getElementById("history-detail-modal");
  const content = document.getElementById("history-detail-content");
  if (!modal || !content) return;

  content.innerHTML = `
    <div class="space-y-3">
      <div class="flex justify-between items-start">
        <div>
          <h3 class="text-lg font-bold text-slate-900 dark:text-white">${rec.top_condition}</h3>
          <p class="text-xs text-slate-500">${rec.date} • ${rec.patient_name}</p>
        </div>
        <span class="px-2.5 py-1 rounded text-xs font-bold text-white" style="background-color: ${rec.risk_color || '#0284c7'}">
          ${rec.risk_level}
        </span>
      </div>
      <div class="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg text-xs space-y-1">
        <p><strong>Reported Severity:</strong> ${rec.severity_rating} / 10</p>
        <p><strong>Symptoms Logged:</strong> ${rec.symptoms.join(", ")}</p>
        <p><strong>OTC Suggestions:</strong> ${rec.medicines_suggested.length > 0 ? rec.medicines_suggested.join(", ") : "None indicated"}</p>
      </div>
    </div>
  `;
  modal.classList.remove("hidden");
};

window.closeHistoryModal = function() {
  document.getElementById("history-detail-modal")?.classList.add("hidden");
};

window.clearHealthHistory = function() {
  if (confirm("Are you sure you want to clear your stored health history?")) {
    localStorage.setItem("mediai_history", "[]");
    loadHealthHistory();
  }
};

/* ============================================================
   DOCTOR CONSULTATION & BOOKING
   ============================================================ */
function initDoctorConsultation() {
  const container = document.getElementById("doctors-card-grid");
  const specialtyFilter = document.getElementById("doctor-specialty-filter");

  if (!container) return;

  // Render doctors
  function render(specialty = "") {
    let docs = window.MediAIData?.DOCTORS_DIRECTORY || [
      {
        id: "doc_1",
        name: "Dr. Sarah Jenkins, MD",
        specialty: "General Medicine / Internal Medicine",
        hospital: "Apex Health Medical Center",
        experience: "14 years",
        rating: 4.9,
        fee: "$45 (Demo)",
        availability: "Today, 2:30 PM",
        avatar: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150&auto=format&fit=crop&q=80",
        focus_areas: ["Viral Fevers", "Hypertension", "Preventative Care"]
      },
      {
        id: "doc_2",
        name: "Dr. Marcus Vance, MD, FCCP",
        specialty: "Pulmonology & Respiratory Medicine",
        hospital: "Metropolitan Lung Institute",
        experience: "18 years",
        rating: 4.95,
        fee: "$60 (Demo)",
        availability: "Tomorrow, 10:00 AM",
        avatar: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80",
        focus_areas: ["Bronchitis", "Chronic Cough", "Asthma"]
      },
      {
        id: "doc_3",
        name: "Dr. Elena Rostova, MD, FACC",
        specialty: "Cardiology",
        hospital: "Heart & Vascular Specialty Hospital",
        experience: "16 years",
        rating: 4.98,
        fee: "$80 (Demo)",
        availability: "Today, 4:15 PM",
        avatar: "https://images.unsplash.com/photo-1594824813576-93d395786576?w=150&auto=format&fit=crop&q=80",
        focus_areas: ["Chest Pain Triage", "Arrhythmia", "Blood Pressure"]
      },
      {
        id: "doc_4",
        name: "Dr. Rajesh K. Patel, MS (ENT)",
        specialty: "Otolaryngology (ENT Specialist)",
        hospital: "Sinus & Allergy Care Clinic",
        experience: "12 years",
        rating: 4.88,
        fee: "$50 (Demo)",
        availability: "Today, 5:00 PM",
        avatar: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80",
        focus_areas: ["Sinusitis", "Allergic Rhinitis", "Sore Throat"]
      }
    ];

    if (specialty) {
      docs = docs.filter(d => d.specialty.toLowerCase().includes(specialty.toLowerCase()));
    }

    container.innerHTML = docs.map(doc => `
      <div class="p-5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/90 shadow-sm flex flex-col justify-between hover:shadow-md transition">
        <div>
          <div class="flex items-start gap-3 mb-3">
            <img src="${doc.avatar}" alt="${doc.name}" class="w-14 h-14 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shadow-sm" onerror="this.src='https://ui-avatars.com/api/?name=${encodeURIComponent(doc.name)}&background=0284c7&color=fff'">
            <div>
              <div class="flex items-center gap-1.5">
                <h4 class="font-bold text-slate-900 dark:text-white text-base">${doc.name}</h4>
                <span class="text-amber-500 text-xs font-bold">★ ${doc.rating}</span>
              </div>
              <p class="text-xs font-medium text-blue-600 dark:text-teal-400">${doc.specialty}</p>
              <p class="text-[11px] text-slate-500 dark:text-slate-400">${doc.hospital} • ${doc.experience}</p>
            </div>
          </div>

          <div class="flex flex-wrap gap-1 mb-4">
            ${(doc.focus_areas || []).map(f => `<span class="text-[10px] bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded">${f}</span>`).join("")}
          </div>
        </div>

        <div class="pt-3 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between">
          <div>
            <span class="text-[10px] text-slate-400 block">Next Available</span>
            <span class="text-xs font-semibold text-emerald-600 dark:text-emerald-400">🟢 ${doc.availability}</span>
          </div>
          <button onclick="openBookingModal('${doc.id}', '${doc.name}', '${doc.specialty}')" class="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white text-xs font-semibold shadow transition">
            Book Consultation
          </button>
        </div>
      </div>
    `).join("");
  }

  if (specialtyFilter) {
    specialtyFilter.addEventListener("change", (e) => render(e.target.value));
  }

  render();
}

window.openBookingModal = function(id, name, specialty) {
  const modal = document.getElementById("booking-modal");
  const docName = document.getElementById("booking-doc-name");
  const docSpec = document.getElementById("booking-doc-specialty");

  if (!modal) return;
  if (docName) docName.textContent = name;
  if (docSpec) docSpec.textContent = specialty;

  modal.classList.remove("hidden");
};

window.closeBookingModal = function() {
  document.getElementById("booking-modal")?.classList.add("hidden");
  document.getElementById("booking-confirmation")?.classList.add("hidden");
};

window.confirmBooking = function() {
  const modal = document.getElementById("booking-modal");
  const confirmation = document.getElementById("booking-confirmation");
  const code = document.getElementById("booking-confirm-code");

  if (confirmation && code) {
    code.textContent = "MED-" + Math.floor(100000 + Math.random() * 900000);
    confirmation.classList.remove("hidden");
  }
};

/* ============================================================
   NAVIGATION & PRINT FUNCTIONALITY
   ============================================================ */
function initNavigation() {
  const links = document.querySelectorAll(".nav-link");
  links.forEach(link => {
    link.addEventListener("click", (e) => {
      links.forEach(l => l.classList.remove("active"));
      link.classList.add("active");
    });
  });

  // Mobile menu toggle
  const mobileBtn = document.getElementById("mobile-menu-btn");
  const mobileMenu = document.getElementById("mobile-menu");
  if (mobileBtn && mobileMenu) {
    mobileBtn.addEventListener("click", () => {
      mobileMenu.classList.toggle("hidden");
    });
  }
}

window.printClinicalReport = function() {
  window.print();
};
