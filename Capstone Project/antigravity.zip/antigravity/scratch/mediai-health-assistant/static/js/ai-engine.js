/**
 * static/js/ai-engine.js
 * Client-Side AI Diagnostic & Clinical Triage Engine
 * Implements weighted Bayesian probabilistic scoring, red flag triage,
 * contraindication validation, and personalized self-care synthesis.
 */

class ClientAIEngine {
  constructor() {
    this.conditions = {
      "Common Cold": {
        symptoms: ["sneezing", "cold", "runny nose", "sore throat", "cough", "headache", "fatigue"],
        primary: ["cold", "sneezing", "runny nose"],
        base_severity: "Low",
        description: "A viral infectious disease of the upper respiratory tract that primarily affects the mucosal lining of the nose, throat, and sinuses.",
        explanation: "Your reported symptoms of sneezing, nasal congestion, and mild sore throat strongly correspond to an upper respiratory viral cold."
      },
      "Viral Fever": {
        symptoms: ["fever", "body pain", "headache", "fatigue", "chills", "sweating"],
        primary: ["fever", "body pain", "chills"],
        base_severity: "Moderate",
        description: "An acute febrile illness characterized by elevated body temperature, generalized myalgia (body aches), and constitutional fatigue caused by viral infections.",
        explanation: "The co-occurrence of elevated body temperature, generalized body aches, chills, and fatigue is characteristic of an acute viral febrile response."
      },
      "Influenza (Flu)": {
        symptoms: ["fever", "cough", "body pain", "headache", "fatigue", "chills", "sore throat", "dizziness"],
        primary: ["fever", "cough", "body pain", "chills"],
        base_severity: "Moderate",
        description: "A contagious respiratory illness caused by influenza viruses that infect the nose, throat, and lower respiratory airways.",
        explanation: "The acute onset of high fever, prominent generalized body aches, persistent cough, and fatigue points toward an influenza infection."
      },
      "Acute Bronchitis": {
        symptoms: ["cough", "shortness of breath", "sore throat", "fatigue", "wheezing", "chest pain"],
        primary: ["cough", "wheezing", "sore throat"],
        base_severity: "Moderate",
        description: "Inflammation of the bronchial tubes that carry air to your lungs, causing persistent coughing and airway hyper-reactivity.",
        explanation: "Persistent coughing accompanied by chest discomfort and mild wheezing indicates bronchial airway inflammation."
      },
      "Allergic Rhinitis / Allergy": {
        symptoms: ["sneezing", "cold", "runny nose", "sore throat", "headache", "skin rash"],
        primary: ["sneezing", "runny nose", "cold"],
        base_severity: "Low",
        description: "An allergic response causing mucosal inflammation of the upper airways upon environmental allergen exposure.",
        explanation: "Prominent sneezing and clear nasal congestion without fever or severe myalgia is most indicative of an allergic reaction."
      },
      "Acid Reflux (GERD)": {
        symptoms: ["acidity", "stomach pain", "chest pain", "nausea", "difficulty swallowing"],
        primary: ["acidity", "stomach pain"],
        base_severity: "Low",
        description: "Gastroesophageal reflux disease occurs when stomach acid repeatedly flows back into the esophagus.",
        explanation: "A burning retrosternal sensation, acidity, and upper abdominal discomfort correlate with gastroesophageal acid reflux."
      },
      "Gastroenteritis (Stomach Flu)": {
        symptoms: ["stomach pain", "vomiting", "diarrhea", "nausea", "fever", "fatigue", "dizziness"],
        primary: ["vomiting", "diarrhea", "stomach pain"],
        base_severity: "Moderate",
        description: "Inflammation of the gastrointestinal tract involving stomach and intestines, triggering acute vomiting and diarrhea.",
        explanation: "Abdominal cramping accompanied by acute vomiting and loose stools points toward acute gastroenteritis or food-related gastric irritation."
      },
      "Tension Headache / Migraine": {
        symptoms: ["headache", "dizziness", "nausea", "fatigue"],
        primary: ["headache", "dizziness"],
        base_severity: "Low",
        description: "A neurological pain syndrome characterized by tension or throbbing pain, often accompanied by sensitivity.",
        explanation: "Isolated cranial pain without fever indicates primary tension cephalalgia or early migraine."
      },
      "Acute Strep / Tonsillitis": {
        symptoms: ["sore throat", "fever", "difficulty swallowing", "headache", "fatigue", "body pain"],
        primary: ["sore throat", "difficulty swallowing", "fever"],
        base_severity: "Moderate",
        description: "Inflammation of the pharyngeal tonsils causing intense throat discomfort, erythema, and painful swallowing.",
        explanation: "Prominent sore throat coupled with painful swallowing and fever indicates tonsillar or pharyngeal inflammation."
      },
      "Contact Dermatitis / Urticaria": {
        symptoms: ["skin rash", "sneezing", "body pain"],
        primary: ["skin rash"],
        base_severity: "Low",
        description: "Cutaneous inflammatory reaction characterized by localized redness, itching, or urticarial wheals.",
        explanation: "Isolated dermal rash and itching suggest acute contact dermatitis or urticaria."
      },
      "Acute Coronary Syndrome / Cardiac Warning": {
        symptoms: ["chest pain", "shortness of breath", "sweating", "dizziness", "nausea"],
        primary: ["chest pain", "shortness of breath"],
        base_severity: "Emergency",
        description: "Critical cardiorespiratory syndrome characterized by reduced myocardial perfusion requiring urgent triage.",
        explanation: "Substernal chest pressure combined with dyspnea represents an emergency red-flag profile."
      }
    };

    this.medicines = [
      {
        name: "Paracetamol / Acetaminophen",
        category: "Pain Reliever & Antipyretic (Fever Reducer)",
        symptoms_targeted: ["fever", "headache", "body pain", "sore throat"],
        general_purpose: "Provides temporary symptomatic relief of mild-to-moderate fever, tension headaches, and generalized body aches.",
        precautions: "Do not exceed maximum daily limits (typically 3000-4000mg/day for adults). Avoid alcohol. Consult a physician if history of liver disease.",
        side_effects: "Rare at recommended doses; potential hepatotoxicity in case of accidental overdose.",
        safety_notes: "Check combination cough/cold medications to prevent unintentional acetaminophen toxicity.",
        contraindications: ["liver disease", "hepatic impairment"]
      },
      {
        name: "Cetirizine / Loratadine",
        category: "Second-Generation Antihistamine",
        symptoms_targeted: ["sneezing", "cold", "runny nose", "skin rash"],
        general_purpose: "Blocks histamine receptors to alleviate allergic sneezing, watery rhinorrhea, itchy eyes, and allergic hives.",
        precautions: "May cause slight drowsiness in sensitive individuals. Use caution when operating machinery. Dose adjustment in renal impairment.",
        side_effects: "Dry mouth, mild fatigue, transient drowsiness.",
        safety_notes: "Non-sedating during daytime for most adults; does not cure viral infections.",
        contraindications: ["renal failure", "kidney disease"]
      },
      {
        name: "Antacid (Magnesium/Aluminum Hydroxide / Calcium Carbonate)",
        category: "Acid-Neutralizing Agent",
        symptoms_targeted: ["acidity", "stomach pain"],
        general_purpose: "Neutralizes excess stomach acid rapidly to soothe heartburn, sour stomach, and acid indigestion.",
        precautions: "Take 1-2 hours apart from other medications to prevent drug-absorption interference.",
        side_effects: "Constipation (calcium/aluminum) or mild diarrhea (magnesium formulations).",
        safety_notes: "Not intended for prolonged daily use exceeding 14 days without medical consultation.",
        contraindications: ["chronic kidney disease"]
      },
      {
        name: "Saline Nasal Spray (0.9% Sodium Chloride)",
        category: "Supportive Nasal Wash & Mucosal Hydration",
        symptoms_targeted: ["cold", "sneezing", "cough"],
        general_purpose: "Hydrates dry nasal passages, thins thick mucus secretions, and flushes environmental allergens.",
        precautions: "Safe across all age groups including infants and pregnancy. Use clean individual nozzles.",
        side_effects: "Transient mild nasal tingling if mucosal lining is severely inflamed.",
        safety_notes: "Drug-free, non-rebound alternative to medicated nasal decongestant sprays.",
        contraindications: []
      },
      {
        name: "Dextromethorphan / Guaifenesin (Cough Care)",
        category: "Supportive Antitussive / Expectorant",
        symptoms_targeted: ["cough"],
        general_purpose: "Suppresses non-productive dry coughs (Dextromethorphan) or loosens mucus in productive coughs (Guaifenesin).",
        precautions: "Avoid combining with MAOI antidepressants. Ensure generous water consumption with expectorants.",
        side_effects: "Mild drowsiness, slight dizziness, gastrointestinal upset.",
        safety_notes: "If coughing up blood, high fever, or green phlegm, do not self-medicate; see a doctor.",
        contraindications: ["chronic bronchitis", "maoi medication"]
      },
      {
        name: "Oral Rehydration Salts (ORS)",
        category: "Electrolyte Fluid Replacement Solution",
        symptoms_targeted: ["vomiting", "diarrhea", "dizziness", "fatigue"],
        general_purpose: "Restores vital fluids and balanced electrolytes lost during acute gastrointestinal episodes.",
        precautions: "Mix in exact measured volume of drinking water. Do not boil once mixed.",
        side_effects: "Extremely safe and well-tolerated.",
        safety_notes: "First-line World Health Organization (WHO) recommended supportive care for fluid loss.",
        contraindications: []
      }
    ];

    this.redFlagSymptoms = {
      "chest pain": "Severe chest pain can signify acute myocardial infarction or pulmonary embolism.",
      "shortness of breath": "Severe difficulty breathing may indicate acute asthma exacerbation or cardiac failure.",
      "loss of consciousness": "Syncope warrants immediate neurologic and cardiovascular evaluation.",
      "severe bleeding": "Acute hemorrhage requires immediate in-person medical intervention.",
      "sudden weakness": "Unilateral weakness or facial droop indicates potential acute ischemic stroke.",
      "severe allergic reaction": "Anaphylaxis requires immediate emergency medical attention."
    };
  }

  detectRedFlags(symptoms, severityRating) {
    const flags = [];
    symptoms.forEach(sym => {
      const clean = sym.toLowerCase();
      if (this.redFlagSymptoms[clean]) {
        flags.push({
          symptom: sym.charAt(0).toUpperCase() + sym.slice(1),
          warning: this.redFlagSymptoms[clean]
        });
      }
    });

    if (severityRating >= 8 && symptoms.some(s => ["chest pain", "shortness of breath", "dizziness"].includes(s.toLowerCase()))) {
      if (!flags.some(f => f.symptom.includes("Cardiorespiratory"))) {
        flags.push({
          symptom: "Acute Cardiorespiratory Warning",
          warning: "High severity accompanied by cardiorespiratory symptoms warrants immediate emergency evaluation."
        });
      }
    }

    if (severityRating >= 9) {
      if (!flags.some(f => f.symptom.includes("Critical Pain"))) {
        flags.push({
          symptom: "Critical Pain / Distress Score",
          warning: "A severity score of 9-10 indicates acute distress requiring immediate in-person healthcare care."
        });
      }
    }

    return flags;
  }

  calculateRiskMeter(symptoms, severityRating, durationStr, redFlags) {
    if (redFlags.length > 0 || severityRating >= 9) {
      return {
        level: "Emergency",
        color: "#ef4444",
        badge: "🔴 Emergency",
        score: Math.min(100, Math.max(88, severityRating * 10)),
        message: "Immediate emergency medical evaluation is strongly recommended. Do not delay professional medical care."
      };
    }

    let score = severityRating * 7;
    const dur = (durationStr || "").toLowerCase();
    if (dur.includes("week") || dur.includes(">")) score += 15;
    else if (dur.includes("4-7")) score += 8;

    score += Math.min(20, symptoms.length * 3);

    if (score >= 65 || severityRating >= 7) {
      return {
        level: "High Risk",
        color: "#f97316",
        badge: "🟠 High Risk",
        score: Math.min(84, Math.round(score)),
        message: "Significant clinical symptoms detected. Professional medical evaluation is advised within 24 hours."
      };
    } else if (score >= 40 || severityRating >= 4) {
      return {
        level: "Moderate Risk",
        color: "#eab308",
        badge: "🟡 Moderate Risk",
        score: Math.min(64, Math.round(score)),
        message: "Moderate symptoms detected. Monitor closely, maintain supportive self-care, and consult a doctor if condition persists."
      };
    } else {
      return {
        level: "Low Risk",
        color: "#10b981",
        badge: "🟢 Low Risk",
        score: Math.max(18, Math.min(39, Math.round(score))),
        message: "Mild symptoms. Home supportive care, adequate hydration, and rest are appropriate for initial management."
      };
    }
  }

  predictConditions(symptoms) {
    if (!symptoms || symptoms.length === 0) return [];
    const scores = {};

    Object.keys(this.conditions).forEach(condName => {
      const cond = this.conditions[condName];
      let matches = 0;
      let primaryMatches = 0;

      symptoms.forEach(s => {
        const clean = s.toLowerCase();
        if (cond.symptoms.includes(clean)) matches++;
        if (cond.primary.includes(clean)) primaryMatches++;
      });

      if (matches > 0) {
        // Weighted heuristic calculation
        const matchRatio = matches / cond.symptoms.length;
        scores[condName] = (matchRatio * 0.45) + (primaryMatches * 0.4);
      } else {
        scores[condName] = 0;
      }
    });

    const sorted = Object.entries(scores)
      .filter(([_, score]) => score > 0)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3);

    if (sorted.length === 0) {
      return [{
        condition: "Non-Specific Viral Syndrome",
        confidence: 55,
        description: "A generalized cluster of symptoms commonly observed during mild viral exposures or physical exhaustion.",
        explanation: "Symptoms do not match a single localized condition definitively. Continued rest and monitoring are suggested.",
        base_severity: "Low"
      }];
    }

    const total = sorted.reduce((sum, item) => sum + item[1], 0) || 1;
    return sorted.map(([condName, score], idx) => {
      const cond = this.conditions[condName];
      let confidence = Math.round(Math.min(88, Math.max(42, (score / total) * 100)));
      // Ensure decreasing order
      if (idx === 0) confidence = Math.max(confidence, 72);
      if (idx === 1) confidence = Math.min(confidence, 68);
      if (idx === 2) confidence = Math.min(confidence, 48);

      return {
        condition: condName,
        confidence: confidence,
        description: cond.description,
        explanation: cond.explanation,
        base_severity: cond.base_severity
      };
    });
  }

  evaluateMedicineSafety(conditions, symptoms, patientProfile, redFlags) {
    const isEmergency = redFlags.length > 0 || (patientProfile.severity_rating >= 9);

    if (isEmergency) {
      return {
        blocked: true,
        reason: "emergency",
        medicines: [],
        alert_title: "🚨 Urgent Medical Attention Recommended",
        alert_message: "Your reported symptoms indicate potential clinical urgency. Routine self-medication is strongly discouraged. Please seek immediate professional medical evaluation."
      };
    }

    const missingFields = [];
    if (!patientProfile.age) missingFields.push("Age");
    if (!patientProfile.allergies_provided) missingFields.push("Allergy Status");

    if (missingFields.length > 0) {
      return {
        blocked: true,
        reason: "missing_info",
        missing_fields: missingFields,
        medicines: [],
        alert_title: "⚠️ Safety Information Required",
        alert_message: `Please provide your ${missingFields.join(" and ")} before personalized medicine guidance can be safely displayed.`
      };
    }

    const existingConditions = (patientProfile.existing_conditions || []).map(c => c.toLowerCase());
    const allergies = (patientProfile.allergies || []).map(a => a.toLowerCase());
    const suitable = [];

    this.medicines.forEach(med => {
      const targetsSymptom = med.symptoms_targeted.some(s => symptoms.some(userS => userS.toLowerCase().includes(s)));
      if (!targetsSymptom) return;

      let contraindicated = false;
      let contraindicationReason = "";

      existingConditions.forEach(cond => {
        med.contraindications.forEach(c => {
          if (cond.includes(c) || c.includes(cond)) {
            contraindicated = true;
            contraindicationReason = `Use with caution or avoid due to reported history of ${cond}.`;
          }
        });
      });

      allergies.forEach(allergy => {
        if (allergy.includes("paracetamol") && med.name.includes("Paracetamol")) {
          contraindicated = true;
          contraindicationReason = "Contraindicated due to reported Paracetamol/Acetaminophen allergy.";
        }
      });

      const specialWarnings = [];
      const ageNum = parseInt(patientProfile.age, 10);
      if (ageNum < 12) {
        specialWarnings.push("Pediatric Precaution: Dosages for children under 12 must strictly follow a pediatrician's guidance. Never administer adult formulations.");
      } else if (ageNum >= 65) {
        specialWarnings.push("Geriatric Note: Older adults may have higher drug sensitivity; start with lowest therapeutic OTC dosage.");
      }

      if (patientProfile.is_pregnant) {
        specialWarnings.push("Pregnancy Precaution: Always consult an Obstetrician/Gynecologist before using any OTC medication during pregnancy.");
      }

      suitable.push({
        name: med.name,
        category: med.category,
        target_symptoms: med.symptoms_targeted.filter(s => symptoms.some(u => u.toLowerCase().includes(s))),
        general_purpose: med.general_purpose,
        precautions: med.precautions,
        side_effects: med.side_effects,
        safety_notes: med.safety_notes,
        is_contraindicated: contraindicated,
        contraindication_warning: contraindicationReason,
        special_warnings: specialWarnings
      });
    });

    return {
      blocked: false,
      medicines: suitable,
      alert_title: null,
      alert_message: null
    };
  }

  getSelfCare(symptoms) {
    const list = [
      {
        title: "Optimal Hydration",
        icon: "💧",
        detail: "Drink 2.5 to 3 liters of fluids (warm water, clear broths, electrolyte water). Fluid intake thins respiratory mucus and prevents fever-induced dehydration."
      },
      {
        title: "Adequate Rest & Sleep",
        icon: "😴",
        detail: "Ensure 8-9 hours of restorative sleep. Physical rest optimizes immunological function and accelerates tissue recovery."
      },
      {
        title: "Gentle & Nourishing Diet",
        icon: "🥗",
        detail: "Consume easily digestible, warm meals such as vegetable soups, rice porridge, and vitamin-rich fruits. Avoid heavy, greasy, or spicy foods."
      }
    ];

    const symClean = symptoms.map(s => s.toLowerCase());

    if (symClean.some(s => s.includes("fever") || s.includes("chill"))) {
      list.push({
        title: "Temperature Monitoring",
        icon: "🌡️",
        detail: "Log body temperature with an oral thermometer every 4-6 hours. Seek medical attention if fever exceeds 102°F or persists past 3 days."
      });
    }

    if (symClean.some(s => s.includes("cough") || s.includes("cold") || s.includes("throat") || s.includes("sneez"))) {
      list.push({
        title: "Steam Inhalation & Salt Gargle",
        icon: "💨",
        detail: "Inhale warm steam for 5-10 minutes twice daily to clear nasal passages. Gargle with warm salt water to relieve pharyngeal irritation."
      });
    }

    list.push({
      title: "Systematic Symptom Tracking",
      icon: "📋",
      detail: "Record symptom onset, progression, and severity in your MediAI Health History to share with your physician during in-person visits."
    });

    list.push({
      title: "Timely Clinical Consultation",
      icon: "👨‍⚕️",
      detail: "Schedule a formal doctor appointment if symptoms fail to improve within 3 to 4 days, or sooner if breathing difficulty or acute pain develops."
    });

    return list;
  }

  analyze(formData) {
    const mainSymptom = (formData.main_symptom || "").trim();
    const additional = formData.additional_symptoms || [];
    const allSymptoms = [];
    if (mainSymptom) allSymptoms.push(mainSymptom);
    additional.forEach(s => {
      if (s && !allSymptoms.includes(s)) allSymptoms.push(s);
    });

    const severityRating = parseInt(formData.severity_rating || 3, 10);
    const redFlags = this.detectRedFlags(allSymptoms, severityRating);
    const riskMeter = this.calculateRiskMeter(allSymptoms, severityRating, formData.duration, redFlags);
    const conditions = this.predictConditions(allSymptoms);
    const primaryCond = conditions[0] || {};
    const medicineEval = this.evaluateMedicineSafety(conditions, allSymptoms, formData, redFlags);
    const selfCare = this.getSelfCare(allSymptoms);

    return {
      patient: {
        name: formData.patient_name || "Patient",
        age: formData.age,
        gender: formData.gender || "Not specified",
        duration: formData.duration || "1-3 days",
        severity_rating: severityRating,
        is_pregnant: Boolean(formData.is_pregnant)
      },
      symptoms: {
        main: mainSymptom,
        normalized: allSymptoms,
        count: allSymptoms.length
      },
      red_flags: redFlags,
      risk_meter: riskMeter,
      possible_conditions: conditions,
      ai_explanation: primaryCond.explanation || "Symptom profile is non-specific. Rest and continued clinical observation are suggested.",
      medicine_evaluation: medicineEval,
      self_care_recommendations: selfCare,
      timestamp: new Date().toISOString()
    };
  }
}

window.clientAIEngine = new ClientAIEngine();
