/**
 * static/js/chatbot.js
 * MediAI Assistant Conversational Interface
 * Handles natural language symptom interactions, typing simulation,
 * quick suggestion pills, and clinical contextual responses.
 */

class MediAIChatbot {
  constructor() {
    this.chatContainer = document.getElementById("chat-messages");
    this.chatInput = document.getElementById("chat-input");
    this.sendBtn = document.getElementById("chat-send-btn");
    this.typingIndicator = document.getElementById("chat-typing");
    this.isResponding = false;

    this.initEventListeners();
    this.initSuggestedButtons();
  }

  initEventListeners() {
    if (this.sendBtn) {
      this.sendBtn.addEventListener("click", () => this.sendMessage());
    }

    if (this.chatInput) {
      this.chatInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          this.sendMessage();
        }
      });
    }
  }

  initSuggestedButtons() {
    const suggestionPills = document.querySelectorAll(".chat-suggested-pill");
    suggestionPills.forEach(pill => {
      pill.addEventListener("click", () => {
        const text = pill.getAttribute("data-query") || pill.textContent.trim();
        this.chatInput.value = text;
        this.sendMessage();
      });
    });
  }

  formatTimestamp() {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  formatMarkdown(text) {
    if (!text) return "";
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/• (.*?)(?:\n|$)/g, '<li class="ml-4 list-disc">$1</li>')
      .replace(/\n\n/g, '<div class="h-2"></div>')
      .replace(/\n/g, '<br>');
  }

  appendUserMessage(text) {
    const time = this.formatTimestamp();
    const msgDiv = document.createElement("div");
    msgDiv.className = "flex items-start justify-end gap-3 message-fade-in";
    msgDiv.innerHTML = `
      <div class="flex flex-col items-end max-w-[82%] sm:max-w-[70%]">
        <div class="bg-gradient-to-r from-blue-600 to-teal-600 text-white px-4 py-3 rounded-2xl rounded-tr-none shadow-md text-sm sm:text-base leading-relaxed break-words">
          ${this.escapeHtml(text)}
        </div>
        <span class="text-[11px] text-slate-400 mt-1 mr-1">${time}</span>
      </div>
      <div class="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-200 text-xs font-bold shrink-0 shadow-inner">
        ME
      </div>
    `;
    this.chatContainer.appendChild(msgDiv);
    this.scrollToBottom();
  }

  appendBotMessage(text, suggestions = []) {
    const time = this.formatTimestamp();
    const msgDiv = document.createElement("div");
    msgDiv.className = "flex items-start gap-3 message-fade-in";

    let suggestionHtml = "";
    if (suggestions && suggestions.length > 0) {
      suggestionHtml = `
        <div class="flex flex-wrap gap-2 mt-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          ${suggestions.map(s => `
            <button class="chat-reply-pill text-xs font-medium bg-blue-50 dark:bg-slate-800 hover:bg-blue-100 dark:hover:bg-slate-700 text-blue-700 dark:text-teal-300 px-3 py-1.5 rounded-full border border-blue-200/60 dark:border-slate-700 transition flex items-center gap-1">
              <span>👉</span> ${s}
            </button>
          `).join("")}
        </div>
      `;
    }

    msgDiv.innerHTML = `
      <div class="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-teal-500 text-white flex items-center justify-center text-xs font-bold shrink-0 shadow-md">
        🤖
      </div>
      <div class="flex flex-col items-start max-w-[85%] sm:max-w-[75%]">
        <div class="bg-white dark:bg-slate-800/95 border border-slate-200/80 dark:border-slate-700/80 text-slate-800 dark:text-slate-100 px-4 py-3 rounded-2xl rounded-tl-none shadow-sm text-sm sm:text-base leading-relaxed break-words">
          ${this.formatMarkdown(text)}
          ${suggestionHtml}
        </div>
        <span class="text-[11px] text-slate-400 mt-1 ml-1 flex items-center gap-1">
          <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> MediAI • ${time}
        </span>
      </div>
    `;

    this.chatContainer.appendChild(msgDiv);

    // Attach click handlers to newly created suggestion pills
    msgDiv.querySelectorAll(".chat-reply-pill").forEach(btn => {
      btn.addEventListener("click", () => {
        const query = btn.textContent.replace("👉", "").trim();
        if (query.includes("Start Health Analysis") || query.includes("Symptom Analysis")) {
          document.getElementById("nav-analysis-btn")?.click();
        } else if (query.includes("Find a Doctor") || query.includes("Doctor")) {
          document.getElementById("nav-doctors-btn")?.click();
        } else {
          this.chatInput.value = query;
          this.sendMessage();
        }
      });
    });

    this.scrollToBottom();
  }

  showTyping() {
    if (this.typingIndicator) {
      this.typingIndicator.classList.remove("hidden");
      this.scrollToBottom();
    }
  }

  hideTyping() {
    if (this.typingIndicator) {
      this.typingIndicator.classList.add("hidden");
    }
  }

  scrollToBottom() {
    if (this.chatContainer) {
      setTimeout(() => {
        this.chatContainer.scrollTop = this.chatContainer.scrollHeight;
      }, 50);
    }
  }

  escapeHtml(str) {
    const div = document.createElement("div");
    div.innerText = str;
    return div.innerHTML;
  }

  async sendMessage() {
    const text = this.chatInput.value.trim();
    if (!text || this.isResponding) return;

    this.appendUserMessage(text);
    this.chatInput.value = "";
    this.isResponding = true;
    this.showTyping();

    // Try backend API first; fallback to client-side NLP generator
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text })
      });

      if (response.ok) {
        const data = await response.json();
        setTimeout(() => {
          this.hideTyping();
          this.appendBotMessage(data.reply, data.suggested_queries);
          this.isResponding = false;
        }, 500);
        return;
      }
    } catch (e) {
      // Backend not running, execute client fallback
    }

    // Client-side Fallback Responder
    setTimeout(() => {
      this.hideTyping();
      const replyObj = this.generateClientReply(text);
      this.appendBotMessage(replyObj.reply, replyObj.suggestions);
      this.isResponding = false;
    }, 600);
  }

  generateClientReply(query) {
    const clean = query.toLowerCase();

    if (clean.includes("headache") || clean.includes("migraine")) {
      return {
        reply: "Headaches can be caused by tension/stress, eye strain, dehydration, sinus congestion, or lack of sleep.\n\n" +
               "💡 **Supportive measures:**\n" +
               "• Rest in a quiet, dark room\n" +
               "• Drink a tall glass of cool water\n" +
               "• Apply a cold cloth to forehead or temples\n\n" +
               "🚨 **Emergency Alert:** If accompanied by sudden vision loss, high fever with stiff neck, or sudden weakness, seek immediate emergency medical care.",
        suggestions: ["What medicine information is available for mild fever?", "When should I see a doctor?", "Start Health Analysis"]
      };
    }

    if (clean.includes("fever") || clean.includes("temperature")) {
      return {
        reply: "A fever is usually your immune system's mechanism for fighting off viral or bacterial pathogens.\n\n" +
               "🌡️ **Recommended Guidelines:**\n" +
               "• Ensure abundant fluid intake to prevent dehydration\n" +
               "• Rest comfortably in well-ventilated, loose attire\n" +
               "• For mild-to-moderate fever, OTC Paracetamol (Acetaminophen) is commonly utilized if no contraindications exist\n\n" +
               "⚠️ Consult a physician if fever exceeds 102°F (38.9°C) or continues past 72 hours.",
        suggestions: ["I have fever and cough. What should I do?", "What medicine helps with body pain?", "Start full symptom analysis"]
      };
    }

    if (clean.includes("cough") || clean.includes("throat") || clean.includes("cold")) {
      return {
        reply: "Upper respiratory symptoms such as cough, sore throat, and nasal congestion are most frequently viral in origin.\n\n" +
               "💧 **Supportive Care:**\n" +
               "• Warm salt water gargle (1/2 tsp salt in 250ml warm water) 3x daily\n" +
               "• Warm steam inhalation to open bronchial pathways\n" +
               "• Saline nasal spray to rinse sinuses and loosen secretions\n\n" +
               "Note: Antibiotics do not cure viral infections and require physician supervision.",
        suggestions: ["What could cause my headache?", "When should I see a doctor?", "Check my symptoms"]
      };
    }

    if (clean.includes("dizzy") || clean.includes("dizziness")) {
      return {
        reply: "Dizziness may stem from dehydration, inner ear imbalance, sudden posture changes (orthostatic drops), low blood sugar, or fatigue.\n\n" +
               "🧘 **Immediate Safety Steps:**\n" +
               "• Sit down or lie down immediately to prevent falls\n" +
               "• Slowly sip water or an electrolyte beverage\n" +
               "• Avoid rapid head movements\n\n" +
               "🚨 If accompanied by chest tightness, slurred speech, or numbness, call emergency services immediately.",
        suggestions: ["When should I see a doctor?", "Book Doctor Consultation", "Start Health Analysis"]
      };
    }

    if (clean.includes("when should i see a doctor") || clean.includes("doctor")) {
      return {
        reply: "You should seek professional medical evaluation if:\n\n" +
               "• Symptoms persist longer than 3-5 days without improvement\n" +
               "• High fever (>102°F) or fever that does not respond to antipyretics\n" +
               "• You have preexisting chronic conditions (diabetes, heart disease, asthma)\n" +
               "• Red flag symptoms emerge: chest pain, severe shortness of breath, sudden numbness.",
        suggestions: ["Find a Doctor", "Start Health Analysis", "What could cause my headache?"]
      };
    }

    if (clean.includes("medicine") || clean.includes("paracetamol")) {
      return {
        reply: "General OTC (over-the-counter) medicine categories for mild symptoms include:\n\n" +
               "• **Paracetamol:** Mild pain and fever reduction (monitor liver health; avoid exceeding recommended limits)\n" +
               "• **Cetirizine:** Allergic sneezing, runny nose, or mild skin hives\n" +
               "• **Antacids:** Occasional heartburn or gastric acid irritation\n" +
               "• **Saline Nasal Sprays:** Safe mucosal hydration and decongestion\n\n" +
               "⚠️ **Safety Reminder:** These are general educational descriptions, not prescriptions. Always verify with a doctor or pharmacist.",
        suggestions: ["Start Health Analysis", "When should I see a doctor?", "What could cause my headache?"]
      };
    }

    return {
      reply: `Thank you for sharing your concern: "${query}". \n\n` +
             "As your MediAI assistant, I provide preliminary health information, risk stratification, and educational OTC guidance. " +
             "To receive a personalized clinical assessment with condition probabilities and severity scoring, please use our comprehensive **Symptom Analysis** form.",
      suggestions: ["Start Health Analysis", "What could cause my headache?", "When should I see a doctor?"]
    };
  }
}

// Initialized in app.js
window.MediAIChatbot = MediAIChatbot;
