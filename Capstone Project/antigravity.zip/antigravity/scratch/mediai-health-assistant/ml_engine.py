"""
ml_engine.py - MediAI Machine Learning and Clinical Decision Engine
Final-Year Engineering Project Demonstration
Trained with Scikit-Learn (MultinomialNB & Random Forest ensemble)
"""

import numpy as np
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import MultiLabelBinarizer

# Full vocabulary of recognizable clinical symptoms
SYMPTOM_VOCABULARY = [
    "fever", "headache", "cough", "cold", "sore throat", "chest pain", 
    "stomach pain", "vomiting", "diarrhea", "dizziness", "fatigue", 
    "body pain", "shortness of breath", "sneezing", "acidity", "skin rash",
    "chills", "nausea", "loss of taste or smell", "runny nose", 
    "joint pain", "wheezing", "difficulty swallowing", "sweating",
    "loss of consciousness", "severe bleeding", "sudden weakness", "severe allergic reaction"
]

# Red flag symptoms that require immediate emergency evaluation
RED_FLAG_SYMPTOMS = {
    "chest pain": "Severe chest pain can be an indicator of acute coronary syndrome, pericarditis, or pulmonary embolism.",
    "shortness of breath": "Severe dyspnea (difficulty breathing) may indicate acute asthma exacerbation, pneumonia, or cardiac distress.",
    "loss of consciousness": "Syncope or loss of consciousness requires immediate neurologic and cardiovascular evaluation.",
    "severe bleeding": "Acute uncontrolled hemorrhage constitutes an emergency requiring immediate intervention.",
    "sudden weakness": "Sudden unilateral weakness or facial droop may indicate an acute cerebrovascular accident (stroke).",
    "severe allergic reaction": "Anaphylaxis symptoms (airway swelling, severe hives, hypotension) require immediate emergency epinephrine."
}

# Clinical Knowledge Base of Conditions and Symptoms
CONDITIONS_DATABASE = {
    "Common Cold": {
        "symptoms": ["sneezing", "cold", "runny nose", "sore throat", "cough", "headache", "fatigue"],
        "primary": ["cold", "sneezing", "runny nose"],
        "base_severity": "Low",
        "description": "A viral infectious disease of the upper respiratory tract primarily affecting the mucosa of the nose, throat, and sinuses.",
        "explanation": "Your reported symptoms of sneezing, mild cough, and nasal congestion strongly align with upper respiratory viral rhinitis (common cold)."
    },
    "Viral Fever": {
        "symptoms": ["fever", "body pain", "headache", "fatigue", "chills", "sweating"],
        "primary": ["fever", "body pain", "chills"],
        "base_severity": "Moderate",
        "description": "An acute febrile illness characterized by elevated body temperature, generalized myalgia (body aches), and constitutional fatigue caused by viral infections.",
        "explanation": "The combination of elevated body temperature, generalized body aches, chills, and fatigue is characteristic of an acute viral febrile response."
    },
    "Influenza (Flu)": {
        "symptoms": ["fever", "cough", "body pain", "headache", "fatigue", "chills", "sore throat", "dizziness"],
        "primary": ["fever", "cough", "body pain", "chills"],
        "base_severity": "Moderate",
        "description": "A contagious respiratory illness caused by influenza viruses that infect the nose, throat, and lower respiratory tract.",
        "explanation": "The sudden onset of high fever, prominent body aches, persistent cough, and profound fatigue suggests an influenza viral infection."
    },
    "Acute Bronchitis": {
        "symptoms": ["cough", "shortness of breath", "sore throat", "fatigue", "wheezing", "chest pain"],
        "primary": ["cough", "wheezing", "sore throat"],
        "base_severity": "Moderate",
        "description": "Inflammation of the large airways (bronchi) that branch off the trachea, commonly preceded by an upper respiratory infection.",
        "explanation": "Persistent coughing accompanied by chest discomfort and mild wheezing indicates bronchial airway inflammation."
    },
    "Allergic Rhinitis / Allergy": {
        "symptoms": ["sneezing", "cold", "runny nose", "sore throat", "headache", "skin rash"],
        "primary": ["sneezing", "runny nose", "cold"],
        "base_severity": "Low",
        "description": "An allergic response causing inflammation of the inside of the nose upon allergen exposure (pollen, dust, dander).",
        "explanation": "Prominent sneezing and clear nasal discharge without fever or prominent myalgia is typical of an allergic inflammatory response."
    },
    "Acid Reflux (GERD)": {
        "symptoms": ["acidity", "stomach pain", "chest pain", "nausea", "difficulty swallowing"],
        "primary": ["acidity", "stomach pain"],
        "base_severity": "Low",
        "description": "Gastroesophageal reflux disease occurs when stomach acid repeatedly flows back into the tube connecting mouth and stomach.",
        "explanation": "Burning substernal sensation, acidity, and epigastric discomfort correlate with gastroesophageal acid reflux."
    },
    "Gastroenteritis (Stomach Flu)": {
        "symptoms": ["stomach pain", "vomiting", "diarrhea", "nausea", "fever", "fatigue", "dizziness"],
        "primary": ["vomiting", "diarrhea", "stomach pain"],
        "base_severity": "Moderate",
        "description": "Inflammation of the gastrointestinal tract involving both the stomach and small intestine, causing acute diarrhea and emesis.",
        "explanation": "The co-occurrence of abdominal cramping, vomiting, and loose stools suggests acute gastroenteritis or food-borne irritation."
    },
    "Tension Headache / Migraine": {
        "symptoms": ["headache", "dizziness", "nausea", "fatigue"],
        "primary": ["headache", "dizziness"],
        "base_severity": "Low",
        "description": "A primary neurological headache disorder characterized by recurrent episodes of throbbing pain, often accompanied by sensory sensitivity.",
        "explanation": "Focal or generalized cranial pain without fever points toward primary tension cephalea or early migraine."
    },
    "Acute Strep / Tonsillitis": {
        "symptoms": ["sore throat", "fever", "difficulty swallowing", "headache", "fatigue", "body pain"],
        "primary": ["sore throat", "difficulty swallowing", "fever"],
        "base_severity": "Moderate",
        "description": "Bacterial or viral inflammation of the pharyngeal tonsils causing severe throat discomfort and painful swallowing (odynophagia).",
        "explanation": "Severe sore throat coupled with painful swallowing and fever indicates significant pharyngeal/tonsillar inflammation."
    },
    "Contact Dermatitis / Urticaria": {
        "symptoms": ["skin rash", "sneezing", "body pain"],
        "primary": ["skin rash"],
        "base_severity": "Low",
        "description": "Inflammatory response of the skin characterized by erythema, pruritus, and localized cutaneous lesions.",
        "explanation": "Isolated cutaneous eruption and pruritus are characteristic of localized allergic or contact dermatitis."
    },
    "Acute Coronary Syndrome / Cardiac Warning": {
        "symptoms": ["chest pain", "shortness of breath", "sweating", "dizziness", "nausea"],
        "primary": ["chest pain", "shortness of breath", "sweating"],
        "base_severity": "Emergency",
        "description": "A spectrum of conditions associated with sudden, reduced blood flow to the heart muscle, requiring immediate emergency evaluation.",
        "explanation": "Substernal chest pressure/pain combined with dyspnea (shortness of breath) or cold diaphoresis represents an emergency red-flag profile."
    }
}

# Educational OTC Medicine Catalog (strictly non-prescription guidance)
MEDICINE_CATALOG = {
    "Paracetamol / Acetaminophen": {
        "category": "Pain Reliever & Antipyretic (Fever Reducer)",
        "symptoms_targeted": ["fever", "headache", "body pain", "sore throat"],
        "general_purpose": "Provides temporary symptomatic relief of mild-to-moderate fever, tension headaches, and generalized body aches.",
        "precautions": "Do not exceed recommended daily limits (typically 3000mg-4000mg/day for adults). Avoid concurrent alcohol consumption. Consult a physician if history of hepatic impairment or chronic liver disease.",
        "side_effects": "Rare at therapeutic doses; nausea, rash. Severe liver toxicity if taken in overdose or combined with other acetaminophen products.",
        "safety_notes": "Check all combination cold medications to prevent accidental double-dosing of acetaminophen.",
        "contraindicated_conditions": ["Liver Disease", "Severe Hepatic Impairment", "Alcohol Dependence"]
    },
    "Cetirizine / Loratadine": {
        "category": "Second-Generation Antihistamine (Non-Drowsy)",
        "symptoms_targeted": ["sneezing", "cold", "runny nose", "skin rash"],
        "general_purpose": "Relieves allergy-mediated histamine responses including persistent sneezing, watery rhinorrhea, itchy eyes, and allergic hives.",
        "precautions": "May cause mild drowsiness in sensitive individuals. Use caution when driving or operating heavy machinery. Adjust dosage in renal impairment.",
        "side_effects": "Dry mouth, mild fatigue, headache, transient somnolence.",
        "safety_notes": "Does not treat bacterial or serious viral infections; acts specifically on histamine H1 receptors.",
        "contraindicated_conditions": ["Severe Renal Failure", "Known Antihistamine Hypersensitivity"]
    },
    "Antacid (Magnesium/Aluminum Hydroxide / Calcium Carbonate)": {
        "category": "Acid-Neutralizing Agent",
        "symptoms_targeted": ["acidity", "stomach pain"],
        "general_purpose": "Quickly neutralizes existing gastric hydrochloric acid to soothe heartburn, sour stomach, and acid indigestion.",
        "precautions": "Take 1-2 hours apart from other oral medications as antacids can bind to and decrease the absorption of other prescription drugs.",
        "side_effects": "Constipation (aluminum/calcium formulations) or loose stools (magnesium formulations), bloating.",
        "safety_notes": "Not intended for continuous use beyond 14 days without physician evaluation.",
        "contraindicated_conditions": ["Severe Kidney Disease", "Hypercalcemia"]
    },
    "Saline Nasal Spray (0.9% Sodium Chloride)": {
        "category": "Supportive Nasal Wash & Mucosal Hydration",
        "symptoms_targeted": ["cold", "sneezing", "cough"],
        "general_purpose": "Gently loosens thick nasal mucus, cleanses environmental irritants, and hydrates dry nasal passages without medications.",
        "precautions": "Safe for all ages including infants and pregnancy. Do not share nozzles to prevent cross-contamination.",
        "side_effects": "Occasional mild nasal stinging if mucous membranes are severely inflamed.",
        "safety_notes": "Non-addictive, drug-free alternative to medicated vasoconstrictor nasal sprays.",
        "contraindicated_conditions": []
    },
    "Dextromethorphan / Guaifenesin (Cough Care)": {
        "category": "OTC Antitussive & Expectorant Support",
        "symptoms_targeted": ["cough"],
        "general_purpose": "Helps relieve cough symptoms: suppressants quiet dry hacking coughs, while expectorants help thin and loosen bronchial secretions.",
        "precautions": "Do not take concurrently with Monoamine Oxidase Inhibitors (MAOIs). Drink plenty of water when taking expectorants to facilitate mucus thinning.",
        "side_effects": "Mild dizziness, drowsiness, nausea, gastrointestinal discomfort.",
        "safety_notes": "If coughing up blood, high fever, or green/rust-colored sputum, seek direct clinical evaluation instead of self-medicating.",
        "contraindicated_conditions": ["Chronic Bronchitis", "Severe Asthma with secretions", "MAOI Medication"]
    },
    "Oral Rehydration Salts (ORS)": {
        "category": "Electrolyte Fluid Replacement Solution",
        "symptoms_targeted": ["vomiting", "diarrhea", "dizziness", "fatigue"],
        "general_purpose": "Replenishes vital water and balanced electrolytes (sodium, potassium, glucose) lost through gastrointestinal distress.",
        "precautions": "Dissolve in the correct volume of clean drinking water as instructed on packet. Do not boil prepared solution.",
        "side_effects": "Extremely safe; mild hypernatremia if prepared too concentrated.",
        "safety_notes": "Essential first-line supportive therapy for any acute episode of diarrhea or vomiting to prevent clinical dehydration.",
        "contraindicated_conditions": []
    }
}

# Self-Care Recommendations Database
SELF_CARE_CATALOG = {
    "hydration": {
        "title": "Optimal Hydration",
        "icon": "💧",
        "detail": "Drink 2.5 to 3 liters of fluids (warm water, broths, electrolyte water). Adequate fluid intake thins respiratory secretions and prevents dehydration."
    },
    "rest": {
        "title": "Adequate Rest & Sleep",
        "icon": "😴",
        "detail": "Allow your immune system to mount an effective defense by getting 8-9 hours of restful sleep and avoiding strenuous physical exertion."
    },
    "diet": {
        "title": "Gentle & Nourishing Diet",
        "icon": "🥗",
        "detail": "Consume easily digestible, warm meals such as vegetable soups, rice porridge, and vitamin-C rich fruits. Avoid spicy, greasy, or acidic items."
    },
    "temperature": {
        "title": "Temperature Monitoring",
        "icon": "🌡️",
        "detail": "Log body temperature with an oral or infrared thermometer every 4-6 hours. Note if fever spikes above 102°F (38.9°C) or fails to respond to antipyretics."
    },
    "steam": {
        "title": "Steam Inhalation & Salt Gargle",
        "icon": "💨",
        "detail": "Inhale warm steam for 5-10 minutes twice daily to clear congested nasal pathways. Gargle with warm salt water for throat inflammation."
    },
    "symptom_tracking": {
        "title": "Systematic Symptom Tracking",
        "icon": "📋",
        "detail": "Keep a written log of symptom progression, onset timing, and changes in severity to share with your physician during clinical consultation."
    },
    "doctor_alert": {
        "title": "Timely Clinical Consultation",
        "icon": "👨‍⚕️",
        "detail": "Schedule an in-person clinical consultation if symptoms fail to improve within 3-4 days, or sooner if new symptoms emerge."
    }
}


class MediAIMachineLearningEngine:
    """Core AI engine integrating ML classification, safety filters, and clinical heuristics."""

    def __init__(self):
        self.mlb = MultiLabelBinarizer()
        self.conditions = list(CONDITIONS_DATABASE.keys())
        self._train_models()

    def _train_models(self):
        """Train scikit-learn models on clinical symptom distributions."""
        X_train_raw = []
        y_train = []

        for cond_name, info in CONDITIONS_DATABASE.items():
            syms = info["symptoms"]
            primary = info["primary"]

            # Sample 1: All symptoms
            X_train_raw.append(syms)
            y_train.append(cond_name)

            # Sample 2: Primary symptoms only
            X_train_raw.append(primary)
            y_train.append(cond_name)

            # Permutations with subsets
            if len(syms) >= 3:
                for i in range(len(syms)):
                    subset = [s for j, s in enumerate(syms) if j != i]
                    if len(subset) >= 2:
                        X_train_raw.append(subset)
                        y_train.append(cond_name)

        self.mlb.fit([SYMPTOM_VOCABULARY])
        X_encoded = self.mlb.transform(X_train_raw)

        self.nb_classifier = MultinomialNB(alpha=0.6)
        self.nb_classifier.fit(X_encoded, y_train)

        self.rf_classifier = RandomForestClassifier(n_estimators=35, random_state=42)
        self.rf_classifier.fit(X_encoded, y_train)

    def normalize_symptoms(self, raw_symptoms):
        """Standardize input symptoms against known vocabulary."""
        normalized = []
        for s in raw_symptoms:
            clean = s.strip().lower()
            for vocab in SYMPTOM_VOCABULARY:
                if vocab == clean or vocab in clean or clean in vocab:
                    if vocab not in normalized:
                        normalized.append(vocab)
                    break
        return normalized

    def check_red_flags(self, symptoms, severity_rating):
        """Identify critical red-flag emergency symptoms."""
        detected_flags = []
        for sym in symptoms:
            if sym in RED_FLAG_SYMPTOMS:
                detected_flags.append({
                    "symptom": sym.title(),
                    "warning": RED_FLAG_SYMPTOMS[sym]
                })

        if severity_rating >= 8 and any(s in symptoms for s in ["chest pain", "shortness of breath", "dizziness"]):
            if not any(f["symptom"] == "Severe Dyspnea / Cardiac Risk" for f in detected_flags):
                detected_flags.append({
                    "symptom": "Acute Cardiorespiratory Warning",
                    "warning": "High reported severity paired with cardiopulmonary symptoms warrants immediate emergency evaluation."
                })

        if severity_rating >= 9:
            if not any(f["symptom"] == "Critical Pain Severity" for f in detected_flags):
                detected_flags.append({
                    "symptom": "Critical Pain / Distress Score",
                    "warning": "A severity rating of 9 or 10 indicates acute distress requiring immediate in-person healthcare evaluation."
                })

        return detected_flags

    def calculate_risk_level(self, symptoms, severity_rating, duration_str, red_flags):
        """Dynamically calculate visual risk meter."""
        if len(red_flags) > 0 or severity_rating >= 9:
            return {
                "level": "Emergency",
                "color": "#ef4444",
                "badge": "🔴 Emergency",
                "score": min(100, max(85, severity_rating * 10)),
                "message": "Immediate emergency medical attention is strongly recommended. Do not delay professional evaluation."
            }

        score = severity_rating * 7

        if "week" in duration_str.lower() or ">" in duration_str:
            score += 15
        elif "4-7" in duration_str.lower():
            score += 8

        score += min(20, len(symptoms) * 3)

        if score >= 65 or severity_rating >= 7:
            return {
                "level": "High Risk",
                "color": "#f97316",
                "badge": "🟠 High Risk",
                "score": min(84, int(score)),
                "message": "Symptoms are significant. Professional medical evaluation is recommended within 24 hours."
            }
        elif score >= 40 or severity_rating >= 4:
            return {
                "level": "Moderate Risk",
                "color": "#eab308",
                "badge": "🟡 Moderate Risk",
                "score": min(64, int(score)),
                "message": "Moderate symptoms detected. Monitor closely, utilize supportive self-care, and consult a doctor if condition persists."
            }
        else:
            return {
                "level": "Low Risk",
                "color": "#10b981",
                "badge": "🟢 Low Risk",
                "score": max(15, min(39, int(score))),
                "message": "Mild symptoms. Home supportive care, adequate hydration, and rest are likely sufficient for initial management."
            }

    def predict_conditions(self, symptoms):
        """Predict conditions using Scikit-Learn probabilistic ensemble combined with clinical heuristics."""
        if not symptoms:
            return []

        vec = self.mlb.transform([symptoms])

        nb_probs = self.nb_classifier.predict_proba(vec)[0]
        nb_classes = self.nb_classifier.classes_

        rf_probs = self.rf_classifier.predict_proba(vec)[0]
        rf_classes = self.rf_classifier.classes_

        combined_scores = {c: 0.0 for c in self.conditions}

        for cls_name, prob in zip(nb_classes, nb_probs):
            combined_scores[cls_name] += prob * 0.5

        for cls_name, prob in zip(rf_classes, rf_probs):
            combined_scores[cls_name] += prob * 0.5

        for cond_name, info in CONDITIONS_DATABASE.items():
            matches = sum(1 for s in symptoms if s in info["symptoms"])
            primary_matches = sum(1 for s in symptoms if s in info["primary"])

            if primary_matches > 0:
                combined_scores[cond_name] += primary_matches * 0.25
            if matches > 0:
                combined_scores[cond_name] += (matches / len(info["symptoms"])) * 0.2

        sorted_conds = sorted(combined_scores.items(), key=lambda x: x[1], reverse=True)
        top_candidates = []

        total_top_score = sum(s for _, s in sorted_conds[:3]) or 1.0

        for cond_name, raw_score in sorted_conds[:3]:
            if raw_score <= 0.05 and len(top_candidates) >= 2:
                continue

            info = CONDITIONS_DATABASE.get(cond_name, {})
            relative_ratio = raw_score / total_top_score
            calibrated_pct = int(min(88, max(42, relative_ratio * 100)))

            top_candidates.append({
                "condition": cond_name,
                "confidence": calibrated_pct,
                "description": info.get("description", ""),
                "explanation": info.get("explanation", ""),
                "base_severity": info.get("base_severity", "Low")
            })

        top_candidates.sort(key=lambda x: x["confidence"], reverse=True)
        return top_candidates

    def evaluate_medicine_safety(self, conditions, symptoms, patient_profile, red_flags):
        """Evaluate OTC medicine recommendations through strict safety checks."""
        is_emergency = len(red_flags) > 0 or patient_profile.get("severity_rating", 1) >= 9

        if is_emergency:
            return {
                "blocked": True,
                "reason": "emergency",
                "medicines": [],
                "alert_title": "🚨 Urgent Medical Attention Recommended",
                "alert_message": "Your symptoms indicate possible serious clinical distress. Routine self-medication is strongly discouraged. Please seek immediate professional medical evaluation."
            }

        age = patient_profile.get("age")
        allergies = [a.lower().strip() for a in patient_profile.get("allergies", [])]
        chronic_conditions = [c.lower().strip() for c in patient_profile.get("existing_conditions", [])]
        is_pregnant = patient_profile.get("is_pregnant", False)

        missing_fields = []
        if age is None or age == "":
            missing_fields.append("Age")
        if not patient_profile.get("allergies_provided", False):
            missing_fields.append("Allergy Information")

        if missing_fields:
            return {
                "blocked": True,
                "reason": "missing_info",
                "missing_fields": missing_fields,
                "medicines": [],
                "alert_title": "⚠️ Safety Information Required",
                "alert_message": f"Please provide your {', '.join(missing_fields)} before personalized medicine guidance can be safely displayed."
            }

        suitable_meds = []

        for med_name, med_info in MEDICINE_CATALOG.items():
            matches_symptom = any(s in med_info["symptoms_targeted"] for s in symptoms)
            if not matches_symptom:
                continue

            contraindicated = False
            contraindication_reason = ""

            for cond in chronic_conditions:
                if any(c.lower() in cond for c in med_info["contraindicated_conditions"]):
                    contraindicated = True
                    contraindication_reason = f"Contraindicated or cautioned with your reported history of {cond.title()}."
                    break

            for allergy in allergies:
                if "paracetamol" in allergy and "Paracetamol" in med_name:
                    contraindicated = True
                    contraindication_reason = "Reported allergy to Paracetamol/Acetaminophen."

            special_warnings = []
            try:
                age_int = int(age)
                if age_int < 12:
                    special_warnings.append("Pediatric Warning: Dosage for children under 12 must strictly follow a pediatrician's advice. Never administer adult formulations.")
                elif age_int >= 65:
                    special_warnings.append("Geriatric Note: Older adults may metabolize medications more slowly; start with lowest therapeutic OTC dose.")
            except (ValueError, TypeError):
                pass

            if is_pregnant:
                special_warnings.append("Pregnancy Precaution: Always consult an Obstetrician/Gynecologist prior to taking any OTC medication during pregnancy.")

            suitable_meds.append({
                "name": med_name,
                "category": med_info["category"],
                "target_symptoms": [s.title() for s in med_info["symptoms_targeted"] if s in symptoms],
                "general_purpose": med_info["general_purpose"],
                "precautions": med_info["precautions"],
                "side_effects": med_info["side_effects"],
                "safety_notes": med_info["safety_notes"],
                "is_contraindicated": contraindicated,
                "contraindication_warning": contraindication_reason,
                "special_warnings": special_warnings
            })

        return {
            "blocked": False,
            "medicines": suitable_meds,
            "alert_title": None,
            "alert_message": None
        }

    def get_self_care_recommendations(self, symptoms, severity_rating):
        """Generate tailored self-care suggestions based on active symptoms."""
        recs = [
            SELF_CARE_CATALOG["hydration"],
            SELF_CARE_CATALOG["rest"],
            SELF_CARE_CATALOG["diet"]
        ]

        if any(s in symptoms for s in ["fever", "chills"]):
            recs.append(SELF_CARE_CATALOG["temperature"])

        if any(s in symptoms for s in ["cough", "cold", "sore throat", "sneezing"]):
            recs.append(SELF_CARE_CATALOG["steam"])

        recs.append(SELF_CARE_CATALOG["symptom_tracking"])
        recs.append(SELF_CARE_CATALOG["doctor_alert"])

        return recs

    def full_assessment(self, data):
        """Execute full end-to-end clinical triage pipeline."""
        patient_name = data.get("patient_name", "Patient").strip() or "Patient"
        age = data.get("age")
        gender = data.get("gender", "Not specified")
        main_symptom = data.get("main_symptom", "").strip()
        additional_symptoms = data.get("additional_symptoms", [])
        duration = data.get("duration", "1-3 days")
        severity_rating = int(data.get("severity_rating", 3))
        existing_conditions = data.get("existing_conditions", [])
        current_medications = data.get("current_medications", "").strip()
        allergies = data.get("allergies", [])
        is_pregnant = bool(data.get("is_pregnant", False))

        raw_list = []
        if main_symptom:
            raw_list.append(main_symptom)
        if isinstance(additional_symptoms, list):
            raw_list.extend(additional_symptoms)
        elif isinstance(additional_symptoms, str):
            raw_list.extend([s.strip() for s in additional_symptoms.split(",") if s.strip()])

        normalized_symptoms = self.normalize_symptoms(raw_list)
        if not normalized_symptoms and main_symptom:
            normalized_symptoms = [main_symptom.lower()]

        # 1. Red Flag & Emergency Detection
        red_flags = self.check_red_flags(normalized_symptoms, severity_rating)

        # 2. Risk Meter Calculation
        risk_meter = self.calculate_risk_level(normalized_symptoms, severity_rating, duration, red_flags)

        # 3. Probabilistic Condition Prediction
        conditions = self.predict_conditions(normalized_symptoms)

        # 4. Clinical Rationale
        if conditions:
            primary_condition = conditions[0]
            ai_explanation = primary_condition["explanation"]
        else:
            ai_explanation = "The reported symptoms present a non-specific clinical profile. Continued symptom monitoring and consultation with a general practitioner are advised."

        # 5. Medicine Safety & OTC Evaluation
        patient_profile = {
            "age": age,
            "allergies": allergies,
            "allergies_provided": data.get("allergies_provided", True),
            "existing_conditions": existing_conditions,
            "current_medications": current_medications,
            "is_pregnant": is_pregnant,
            "severity_rating": severity_rating
        }
        medicine_eval = self.evaluate_medicine_safety(conditions, normalized_symptoms, patient_profile, red_flags)

        # 6. Self-Care Recommendations
        self_care = self.get_self_care_recommendations(normalized_symptoms, severity_rating)

        return {
            "patient": {
                "name": patient_name,
                "age": age,
                "gender": gender,
                "duration": duration,
                "severity_rating": severity_rating,
                "is_pregnant": is_pregnant
            },
            "symptoms": {
                "main": main_symptom,
                "normalized": normalized_symptoms,
                "count": len(normalized_symptoms)
            },
            "red_flags": red_flags,
            "risk_meter": risk_meter,
            "possible_conditions": conditions,
            "ai_explanation": ai_explanation,
            "medicine_evaluation": medicine_eval,
            "self_care_recommendations": self_care,
            "timestamp": "2026-09-03T10:50:00Z"
        }


# Singleton instance
ai_engine = MediAIMachineLearningEngine()
