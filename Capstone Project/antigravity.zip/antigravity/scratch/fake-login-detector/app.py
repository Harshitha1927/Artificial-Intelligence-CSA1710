﻿import os
import joblib
import numpy as np
from flask import Flask, render_template, request, jsonify
from feature_extractor import extract_features, explain_analysis, FEATURE_NAMES

app = Flask(__name__)

# Load model package
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'model.joblib')
model_data = None

def get_model():
    global model_data
    if model_data is None and os.path.exists(MODEL_PATH):
        try:
            model_data = joblib.load(MODEL_PATH)
        except Exception as e:
            print(f"Error loading model: {e}")
    return model_data

SAMPLE_URLS = [
    {
        "category": "Legitimate Login Pages",
        "badge": "safe",
        "urls": [
            {"label": "Google Sign-In", "url": "https://accounts.google.com/signin"},
            {"label": "GitHub Login", "url": "https://github.com/login"},
            {"label": "PayPal Official", "url": "https://www.paypal.com/signin"},
            {"label": "Microsoft 365", "url": "https://login.microsoftonline.com/common/login"},
            {"label": "Amazon Portal", "url": "https://www.amazon.com/ap/signin"}
        ]
    },
    {
        "category": "Phishing & Fake Login Traps",
        "badge": "danger",
        "urls": [
            {"label": "PayPal Cloned Phish", "url": "http://login.paypal.com.verify-account.tk/signin"},
            {"label": "Raw IP Bank Impersonation", "url": "http://192.168.1.100/secure/bankofamerica/login.php"},
            {"label": "Google Typosquat Phish", "url": "http://g00gle-security-update.xyz/login"},
            {"label": "Obfuscated @ Token Trap", "url": "http://www.paypal.com@attacker-site-server.xyz/login.php"},
            {"label": "Deep Subdomain Chain", "url": "http://secure.login.paypal.com.account.verify.client-update.xyz/login"}
        ]
    }
]

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/samples', methods=['GET'])
def get_samples():
    return jsonify(SAMPLE_URLS)

@app.route('/api/analyze', methods=['POST'])
def analyze_url():
    data = request.get_json(force=True, silent=True) or {}
    url = data.get('url', '').strip()
    
    if not url:
        return jsonify({'error': 'Please provide a valid website URL or login link to analyze.'}), 400
        
    try:
        # 1. Feature extraction
        feats, context = extract_features(url)
        
        # 2. Model inference
        model_pkg = get_model()
        if model_pkg:
            feature_names = model_pkg.get('feature_names', FEATURE_NAMES)
            feature_vector = np.array([[feats.get(fn, 0) for fn in feature_names]])
            prob = model_pkg['model'].predict_proba(feature_vector)[0][1]
        else:
            # Fallback heuristic calculation if model not yet trained
            prob = 0.85 if (feats['is_ip'] or feats['brand_spoofed'] or feats['is_suspicious_tld']) else 0.15
            
        # 3. Explainability Engine
        analysis = explain_analysis(url, feats, context, float(prob))
        
        # 4. Actionable recommendations based on verdict
        recommendations = []
        if analysis['verdict'] == 'FAKE / PHISHING':
            recommendations = [
                "⚠️ DO NOT enter your username, password, or OTP on this page.",
                "⚠️ DO NOT download any attached software or credential update forms.",
                "🔒 If you already entered credentials, immediately change passwords on the official website.",
                "🛡️ Report this fraudulent URL to Google Safe Browsing and your security team."
            ]
        elif analysis['verdict'] == 'SUSPICIOUS':
            recommendations = [
                "🔍 Carefully inspect the domain spelling in the browser address bar.",
                "🌐 Rather than clicking links in emails or SMS, type the official address directly.",
                "🔐 Ensure a secure HTTPS connection with a valid security certificate before logging in."
            ]
        else:
            recommendations = [
                "✅ This domain appears authentic with verified structure and protocol standards.",
                "💡 Always remain vigilant and enable Two-Factor Authentication (2FA) for sensitive accounts."
            ]

        response = {
            'success': True,
            'url': url,
            'verdict': analysis['verdict'],
            'verdict_badge': analysis['verdict_badge'],
            'status_message': analysis['status_message'],
            'risk_score': analysis['risk_score'],
            'confidence': round(float(prob) * 100, 1),
            'reasons_fake': analysis['reasons_fake'],
            'reasons_good': analysis['reasons_good'],
            'components': analysis['components'],
            'recommendations': recommendations,
            'features': {k: (bool(v) if isinstance(v, (int, bool)) and v in [0, 1] and k.startswith(('is_', 'has_')) else v) for k, v in feats.items()}
        }
        return jsonify(response)
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500

if __name__ == '__main__':
    print("Starting Fake Login Detector Server on http://127.0.0.1:5000")
    app.run(host='127.0.0.1', port=5000, debug=False)
