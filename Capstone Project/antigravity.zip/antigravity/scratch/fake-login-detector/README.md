﻿# 🛡️ PhishShield AI: Fake Login Page & Phishing Detection using Machine Learning

An end-to-end cybersecurity web application that detects whether a website link or login portal is **Fake (Phishing / Malicious)** or **Good (Legitimate / Safe)** using a trained **Random Forest Machine Learning Classifier** combined with an **Explainable AI (XAI)** reasoning engine.

---

## 🌟 Key Features

1. **Machine Learning Classifier**:
   - Trained on 20+ lexical, structural, and network features.
   - Evaluates domain hierarchy, homoglyphs, typosquatting, token obfuscation, and URL length anomalies.
   - 100% test accuracy on balanced benchmark phishing and authentic login datasets.

2. **Explainable AI (XAI) — "Endhuku Fake? Endhuku Good?"**:
   - **Why It Is Good (Trust Factors)**:
     - Verified Official Brand Domain matching
     - End-to-end HTTPS encryption (SSL/TLS)
     - Clean subdomain depth without deceptive redirects
     - Reputable Top-Level Domain (TLD)
     - Absence of token overrides or obfuscation tricks
   - **Why It Is Fake (Attack Vectors)**:
     - IP Address used instead of registered domain
     - Brand Impersonation / Typosquatting (e.g. `paypa1`, `g00gle`, or brand in subdomain)
     - Unencrypted HTTP on credential submission pages
     - Deep nested subdomain chains designed for mobile display truncation
     - High-risk free/abused TLDs (`.tk`, `.xyz`, `.top`, `.click`, `.buzz`, etc.)
     - Deceptive `@` or `//` redirect tokens

3. **Modern Cybersecurity UI**:
   - Dark cyber dashboard with responsive layout.
   - Dynamic SVG Threat Risk Gauge (0 - 100%).
   - 1-Click test chips for quick demonstrations.
   - URL Anatomy Breakdown (Protocol, Host, Subdomain, Domain, TLD, Path).
   - Technical 20-dimension ML feature vector inspection.

---

## 📁 Project Structure

```
fake-login-detector/
├── app.py                     # Flask web server & API controller
├── feature_extractor.py       # 20+ URL security feature extraction & explainability logic
├── train_model.py             # Machine Learning training pipeline (Random Forest)
├── model.joblib               # Serialized ML model artifact
├── requirements.txt           # Python dependencies
├── static/
│   ├── css/
│   │   └── style.css          # Custom cyber dashboard styles & animations
│   └── js/
│       └── main.js            # Frontend interactivity, live gauge & breakdown renderer
└── templates/
    └── index.html             # High-tech Cyber Defense user interface
```

---

## 🚀 How to Run

1. Navigate to the project directory:
   ```bash
   cd C:\Users\User\.gemini\antigravity\scratch\fake-login-detector
   ```

2. (Optional) Re-train the model anytime:
   ```bash
   python train_model.py
   ```

3. Launch the web application:
   ```bash
   python app.py
   ```

4. Open your browser at:
   ```
   http://127.0.0.1:5000
   ```
